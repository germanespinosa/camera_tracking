/*
 *
 *	pxiplver.h	External	05-Nov-2009
 *
 *	Copyright (C)  2007-2009  EPIX, Inc.  All rights reserved.
 *
 *	DVI Image Processing & Analysis: Names, Version ID, etc.
 *
 */

/*
 * Library version ID's.
 * XCIPL_IDR is machine generated.
 */
#define XCIPL_IDN	"PIXCI(R) Image Processing & Analysis Library"
#define XCIPL_IDV	XCLIB_IDV
#define XCIPL_IDR       "[20.02.25]"
#define XCIPL_IDNVR	XCIPL_IDN " " XCIPL_IDV " " XCIPL_IDR

/*
 *
 *	xclibel8.c	External	25-Feb-2020
 *
 *	Copyright (C)  2004-2019  EPIX, Inc.  All rights reserved.
 *
 *	Example program for XCLIB C Library, SCF Level functions.
 *
 *	Demonstrates XCLIB and/or PXIPL functions for capture and
 *	live display of imager using the Linux DRM-KMS
 *	(Direct Rendering Manager - Kernel Mode Setting) API.
 *	(assumes libdrm development kit installed).
 *	Or using the Linux FBDEV API.
 *	These Linux API are not compatible with the XWindow manager,
 *	as each wishes to 'own' the screen.
 *
 *	The DRM-KMS boilerplate is from the excellent example
 *	    drmmodeset - DRM Modesetting Example
 *	by
 *	    Writen 2014 by Girish Sharma at eInfochips <girish.sharma@einfochips.com>
 *	With some modifications; we also strip most of its longer comments.
 *
 *	We try to clarify which parts of this example are
 *	from drmmodeset.c, which are fbdev interface,
 *	which are generic Unix (e.g. termios),
 *	and which are PIXCI(R)/XCLIB/PXIPL specific.
 *
 *	Cannot be run from a terminal under X windows.
 *	Must be run from a virtual terminal (i.e. ctrl-alt-F2).
 *
 *	Would probably be better for the reader to start
 *	with the GTK display example, xclibel3.c, before
 *	advancing to DRM or FBDEV.
 *
 */


 /*
 *  INSTRUCTIONS:
 *
 *  1)	Set 'define' options below according to the intended camera
 *	and video format.
 *
 *	For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV5L, and SV6 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, or PAL/YC.
 *	(The SV5A and SV5B do not support NTSC/YC or PAL/YC).
 *	For PIXCI(R) SV7 frame grabbers
 *	common choices are RS-170, NSTC, CCIR, or PAL.
 *	For PIXCI(R) SV8 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, PAL/YC.
 *	For PIXCI(R) A110 frame grabbers
 *	common choices are RS-170, CCIR and others, see below.
 *	For PIXCI(R) A310 frame grabbers
 *	common choices are RS-170, CCIR and others, see below.
 *
 *	For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32, D2X, D3X, D3XE,
 *	E1, E1DB, E4, E4DB, E4G2, E4TX2, E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-PoCL,
 *	EB1mini, miniH2b, miniH2, EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB, ELS2, SI, SI1, SI2, and SI4
 *	frame grabbers, use "default" to select the default format for the camera
 *	for which the PIXCI(R) frame grabber is intended.
 *	For non default formats, use XCAP to save the video set-up to a
 *	file, and set FORMAT to the saved file's name.
 *	For camera's with RS-232 control, note that the saved
 *	video set-up only resets the PIXCI(R) frame grabber's
 *	settings, but XCLIB does not reset the camera's settings.
 *	For selected Camera Link cameras w. serial controls,
 *	the video setup file may include serial commands which are
 *	automatically sent by XCLIB to the camera.
 *
 *	Alternately, this could be modified to use any
 *	other convention chosen by the programmer to allow
 *	run time selection of the video format and resolution.
 *
 */

#if !defined(FORMAT) && !defined(FORMATFILE) && !defined(FORMATFILEARG)
				  // For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV5L, SV6
  //#define FORMAT  "RS-170"	  // RS-170 on input 2
  //#define FORMAT  "NTSC"	  // NTSC on input 2
  //#define FORMAT  "NTSC/YC"	  // NSTC S-Video on input 1		  (N/A on SV5A,SV5B)
  //#define FORMAT  "CCIR"	  // CCIR on input 2
  //#define FORMAT  "PAL"	  // PAL (B,D,G,H,I) on input 2
  //#define FORMAT  "PAL/YC"	  // PAL (B,D,G,H,I) S-Video on input 1   (N/A on SV5A,SV5B)
  //#define FORMAT  "default"	  // NSTC S-Video on input 1

				  // For PIXCI(R) SV7
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "NTSC"	  // NTSC
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "PAL"	  // PAL
  //#define FORMAT  "default"	  // NSTC

				  // For PIXCI(R) SV8
  //#define FORMAT  "RS-170"	  // RS-170 on BNC 0
  //#define FORMAT  "NTSC"	  // NTSC on BNC 0
  //#define FORMAT  "NTSC/YC"	  // NSTC S-Video
  //#define FORMAT  "CCIR"	  // CCIR on BNC 0
  //#define FORMAT  "PAL"	  // PAL on BNC 0
  //#define FORMAT  "PAL/YC"	  // PAL (B,D,G,H,I) S-Video
  //#define FORMAT  "default"	  // NSTC on BNC 0

				  // For PIXCI(R) A310
  //#define FORMAT  "default"	  // as preset in board's eeprom
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "Video 720x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 720x480i 60Hz RGB"
  //#define FORMAT  "Video 720x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 720x576i 50Hz RGB"
  //#define FORMAT  "Video 640x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 640x480i 60Hz RGB"
  //#define FORMAT  "Video 768x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 768x576i 50Hz RGB"
  //#define FORMAT  "Video 1920x1080i 60Hz"
  //#define FORMAT  "Video 1920x1080i 60Hz RGB"
  //#define FORMAT  "Video 1920x1080i 50Hz"
  //#define FORMAT  "Video 1920x1080i 50Hz RGB"
  //#define FORMAT  "Video 1920x1080p 60Hz"
  //#define FORMAT  "Video 1920x1080p 60Hz RGB"
  //#define FORMAT  "Video 1920x1080p 50Hz"
  //#define FORMAT  "Video 1920x1080p 50Hz RGB"
  //#define FORMAT  "Video 1280x720p 50Hz"
  //#define FORMAT  "Video 1280x720p 50Hz RGB"
  //#define FORMAT  "Video 1280x720p 60Hz"
  //#define FORMAT  "Video 1280x720p 60Hz RGB"
  //#define FORMAT  "SVGA 800x600 60Hz RGB"
  //#define FORMAT  "SXGA 1280x1024 60Hz RGB"
  //#define FORMAT  "VGA 640x480 60Hz RGB"
  //#define FORMAT  "XGA 1024x768 60Hz RGB"
  //#define FORMAT  "RS343 875i 60Hz"
  //#define FORMAT  "RS343 875i 60Hz RGB"

				  // For PIXCI(R) A110
  //#define FORMAT  "default"	  // as preset in board's eeprom
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "Video 720x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 720x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 640x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 768x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 1920x1080i 60Hz"
  //#define FORMAT  "Video 1920x1080i 50Hz"
  //#define FORMAT  "Video 1920x1080p 60Hz"
  //#define FORMAT  "Video 1920x1080p 50Hz"
  //#define FORMAT  "Video 1280x720p 50Hz"
  //#define FORMAT  "Video 1280x720p 60Hz"
  //#define FORMAT  "RS343 875i 60Hz"

				  // For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32,
				  // D2X, D3X, D3XE, E1, E1DB, E4, E4DB, E4G2, E4TX2,
				  // E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-POCL, EB1mini, miniH2b, miniH2,
				  // EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB,
				  // ELS2, SI, SI1, SI2, SI4
  //#define FORMAT  "default"	  // as per board's intended camera

					  // For any PIXCI(R) frame grabber:
    #define FORMAT	  "default"	  // As per board's default camera or video format.
  //#define FORMATFILE	  "xcvidset.fmt"  // Using format file saved by XCAP.
  //#define FORMATFILEARG		  // Using format file saved by XCAP
					  // specified as command line parameter

#endif


/*
 *  2.1) Set number of expected PIXCI(R) frame grabbers.
 *  The XCLIB Simple 'C' Functions expect that the boards are
 *  identical and operated at the same resolution.
 *
 *  For PIXCI(R) frame grabbers with multiple, functional units,
 *  the XCLIB presents the two halves of the PIXCI(R) E1DB, E4DB, E4G2-2F, E4TX2-2F,
 *  E8CAM, E8DB, e104x4-2f, ECB2, EL1DB, ELS2, miniH2b, SI2, or SV7 frame grabbers,
 *  or the three parts of the PIXCI(R) E4G2-F2B, E4TX2-F2B, or e104x4-f2b frame grabber,
 *  or the four quarters of the PIXCI(R) E4G2-4B, E4TX2-4B, e104x4-4b, or SI4 frame grabbers,
 *  as two, three, or four independent PIXCI(R) frame grabbers, respectively.
 *
 *  This example expects only one unit.
 */
#if !defined(UNITS)
    #define UNITS	1
#endif
#define UNITSMAP    ((1<<UNITS)-1)  // shorthand - bitmap of all units


/*
 *  2.2) Optionally, set driver configuration parameters.
 *  These are normally left to the default, "".
 *  The actual driver configuration parameters include the
 *  desired PIXCI(R) frame grabbers, but to make configuation easier,
 *  code, below, will automatically add board selection to this.
 *
 *  Note: Under Linux, the image frame buffer memory can't be set as
 *  a run time option. It MUST be set via insmod so the memory can
 *  be reserved during Linux's initialization.
 */
#if !defined(DRIVERPARMS)
  //#define DRIVERPARMS "-QU 0"       // don't use interrupts
  //#define DRIVERPARMS "-IM 8192"    // request 8192 mbyte of frame buffer memory
    #define DRIVERPARMS ""	      // default
#endif

/*
 *  3.0) Choose use of the Linux DRM-KMS API or the fbdev API.
 *  Not that either API is built upon the other. But the end result -
 *  access to the raw display frame buffer - is similar.
 *  Only one of these choices should have value 1, the others should be 0.
 */
#if !defined(API_DRM)&&!defined(API_FB)
    #define API_DRM	    1		// DRM-KMS
    #define API_FB	    0		// FBDEV

    #define DRM_DEVCARD     "/dev/dri/card0"

    #define FB_DEVCARD	    "/dev/fb0"	// or /dev/fb1, etc
#endif

/*
 *  3.1)  Choose whether the optional PXIPL Image Processing Library
 *	is available, and some PXIPL functions should be demonstrated.
 *
 *	The USE_PXIPL option supports arbitrary image resizing;
 *	otherwise each image pixel is shown as one display pixel.
 */
#if  !defined(USE_PXIPL)
    #define USE_PXIPL		    0	// Use PXIPL for image display
    #define USE_PIXELCOPY	    1	// copy pixels 1-to-1
#endif
#if !defined(PXIPL_DISPLAY_WIDTH)|!defined(PXIPL_DISPLAY_HEIGHT)
    #define PXIPL_DISPLAY_WIDTH     0	// if not 0, force display area
    #define PXIPL_DISPLAY_HEIGHT    0	// to these sizes, even if there is
					// no room for anything else.
#endif

/*
 *  3.2) Select how display updates should be triggered.
 *  Only one of these choices should have value 1, the others should be 0.
 */
#if !defined(UPDATE_TIMER) && !defined(UPDATE_SIGNAL)
    #define UPDATE_TIMER    1	// Use timer to periodically poll library
				// and test for a new image to be displayed.
				// Simpler (?)
    #define UPDATE_SIGNAL   0	// Use a Signal to trigger display of new image.
				// Slightly more efficient.
				// To be added (see other examples for use of signals).
#endif

/*
 *  3.3) Select whether DRM double buffering is to be used.
 *  Double buffering helps eliminate image flickering.
 *  Double buffering of frame buffers is done by
 *  using pxd_goLivePair for capture, below.
 */
#if !defined(DRM_2BUFFER)
    #define DRM_2BUFFER     0	// To be added
#endif


/*
 *  4)	On some Linux distributions the DRM libraries must be explicitly installed:
 *
 *	apt-get install libdrm-dev
 *
 *  5)	Compile with GCC w/out PXIPL for 32 bit Linux on Intel i386 as:
 *	    gcc -DC_GNU32=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/xclib_i386.a -o xclibel8 -lm
 *	Compile with GCC with PXIPL for 32 bit Linux on Intel i386 as:
 *	    gcc -DC_GNU32=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/pxipl_i386.a ../../lib/xclib_i386.a -o xclibel8 -lm
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on Intel x86_64 as:
 *	    gcc -DC_GNU64=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/xclib_x86_64.a -o xclibel8 -lm
 *	Compile with GCC with PXIPL for 64 bit Linux on Intel x86_64 as:
 *	    gcc -DC_GNU64=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/pxipl_x86_64.a ../../lib/xclib_x86_64.a -o xclibel8 -lm
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *	    gcc -DC_GNU64=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/xclib_aarch64.a -o xclibel8 -lm
 *	Compile with GCC with PXIPL for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *	    gcc -DC_GNU64=000 -DOS_LINUX -I../../inc -no-pie xxclibel8.c -ldrm ../../lib/pxipl_aarch64.a ../../lib/xclib_aarch64.a -o xclibel8 -lm
 *
 *	(The above compilation commands include the DRM library; it isn't
 *	needed if using FBDEV. But, it doesn't hurt and avoids cluttering
 *	these instructions with more compilation variations).
 *
 *	Run as:
 *	    ./xclibel8
 *	from a virtual terminal (i.e. Ctrl-Alt-F2)
 *
 */

/*
 *  NECESSARY INCLUDES:
 */
#include <errno.h>		// c library
#include <fcntl.h>		// c library
#include <unistd.h>		// c library
#include <string.h>		// c library
#include <math.h>		// c library
#include <stdio.h>		// c library
#include <signal.h>		// c library
#include <stdlib.h>		// c library
#include <stdint.h>		// c library
#include <stdarg.h>		// c library
#include <sys/time.h>		// c library
#include <sys/mman.h>		// c library
#include <sys/ioctl.h>		// c library
#include <termios.h>		// c library
#include "xcliball.h"		// XCLIB function prototypes
#if USE_PXIPL
  #include "pxipl.h"	// PXIPL function prototypes         
#endif
#if API_DRM
  #include <xf86drm.h>		// DRM library
  #include <xf86drmMode.h>	// DRM library
#endif
#if API_FB
  #include <linux/fb.h> 	// FB  API
#endif


/*
 * Save typing
 */
 #define MIN(a,b) ((a)<(b)? (a): (b))


/*
 * Display area, image buffer, and associated variables.
 */
uint	    display_width;	    // image display width
uint	    display_height;	    // image display height
uint32	    display_count = 0;	    // display count / rate
#if USE_PXIPL
    pxywindow_s display_wind;	    // display area
#endif
#if USE_PIXELCOPY
    uchar	*rgbbuf = NULL;	    // image buffer
    size_t	rgbbufsize;	    // size of buffer
#endif
double	    video_rate = 0;	    // stats computed
double	    display_rate = 0;	    // stats computed

/*
 * Info on display devices;
 * from drmmodeset.c
 *
 * We re-use portions for fbdev;
 * allowing use of common display code.
 * Thus, the conditional compilation.
 */
struct drmmodeset_dev {
	struct drmmodeset_dev *next;	// points to the next device in the single-linked list

	uint32_t width; 		// width of our buffer object
	uint32_t height;		// height of our buffer object
	uint32_t stride;		// stride value of our buffer object
	uint32_t size;			// size of the memory mapped buffer
	uint8_t *map;			// pointer to the memory mapped buffer

    #if API_DRM
	uint32_t handle;		// a DRM handle to the buffer object that we can draw into
	drmModeModeInfo mode;		// the display mode that we want to use
	uint32_t fb;			// a framebuffer handle with our buffer object as scanout buffer
	uint32_t conn;			// the connector ID that we want to use with this buffer
	uint32_t crtc;			// the crtc ID that we want to use with this connector
	drmModeCrtc *saved_crtc;	// the configuration of the crtc before we changed it.
    #endif
};
struct drmmodeset_dev *drmmodeset_list = NULL;


/***
 *
 *  DRM specifics
 *
 ***/
#if API_DRM

int drmmodeset_open(const char *node)
{
	int fd, r;
	uint64_t has_dumb;

	fd = open(node, O_RDWR | O_CLOEXEC);
	if (fd < 0) {
	    fprintf(stderr, "cannot open '%s' (%d): %m\n", node, errno);
	    return -errno;
	}

	if (drmGetCap(fd, DRM_CAP_DUMB_BUFFER, &has_dumb) < 0
	 || !has_dumb) {
	    fprintf(stderr, "drm device '%s' does not support dumb buffers\n", node);
	    close(fd);
	    return -EOPNOTSUPP;
	}

	return fd;
}

int drmmodeset_find_crtc(int fd, drmModeRes *res, drmModeConnector *conn,
			     struct drmmodeset_dev *dev)
{
	drmModeEncoder *enc;
	unsigned int i, j;
	int32_t crtc;
	struct drmmodeset_dev *iter;

	/* first try the currently conected encoder+crtc */
	if (conn->encoder_id)
	    enc = drmModeGetEncoder(fd, conn->encoder_id);
	else
	    enc = NULL;

	if (enc) {
	    if (enc->crtc_id) {
		crtc = enc->crtc_id;
		for (iter = drmmodeset_list; iter; iter = iter->next) {
		    if (iter->crtc == crtc) {
			crtc = -1;
			break;
		    }
		}
		if (crtc >= 0) {
		    drmModeFreeEncoder(enc);
		    dev->crtc = crtc;
		    return 0;
		}
	    }
	    drmModeFreeEncoder(enc);
	}

	/* If the connector is not currently bound to an encoder or if the
	 * encoder+crtc is already used by another connector (actually unlikely
	 * but lets be safe), iterate all other available encoders to find a
	 * matching CRTC. */
	for (i = 0; i < conn->count_encoders; ++i) {
	    enc = drmModeGetEncoder(fd, conn->encoders[i]);
	    if (!enc) {
		fprintf(stderr, "cannot retrieve encoder %u:%u (%d): %m\n",
				i, conn->encoders[i], errno);
		continue;
	    }

	    /* iterate all global CRTCs */
	    for (j = 0; j < res->count_crtcs; ++j) {
		/* check whether this CRTC works with the encoder */
		if (!(enc->possible_crtcs & (1 << j)))
		    continue;

		/* check that no other device already uses this CRTC */
		crtc = res->crtcs[j];
		for (iter = drmmodeset_list; iter; iter = iter->next) {
		    if (iter->crtc == crtc) {
			crtc = -1;
			break;
		    }
		}

		/* we have found a CRTC, so save it and return */
		if (crtc >= 0) {
		    drmModeFreeEncoder(enc);
		    dev->crtc = crtc;
		    return 0;
		}
	    }
	    drmModeFreeEncoder(enc);
	}

	fprintf(stderr, "cannot find suitable CRTC for connector %u\n",
		conn->connector_id);
	return -ENOENT;
}

int drmmodeset_create_fb(int fd, struct drmmodeset_dev *dev)
{
	struct drm_mode_create_dumb creq;
	struct drm_mode_destroy_dumb dreq;
	struct drm_mode_map_dumb mreq;
	int r;

	/* create dumb buffer */
	memset(&creq, 0, sizeof(creq));
	creq.width = dev->width;
	creq.height = dev->height;
	creq.bpp = 32;
	r = drmIoctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &creq);
	if (r < 0) {
	    fprintf(stderr, "cannot create dumb buffer (%d): %m\n", errno);
	    return -errno;
	}
	dev->stride = creq.pitch;
	dev->size = creq.size;
	dev->handle = creq.handle;

	/* create framebuffer object for the dumb-buffer */
	r = drmModeAddFB(fd, dev->width, dev->height, 24, 32, dev->stride,
			   dev->handle, &dev->fb);
	if (r) {
	    fprintf(stderr, "cannot create framebuffer (%d): %m\n", errno);
	    r = -errno;
	    goto err_destroy;
	}

	/* prepare buffer for memory mapping */
	memset(&mreq, 0, sizeof(mreq));
	mreq.handle = dev->handle;
	r = drmIoctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &mreq);
	if (r) {
	    fprintf(stderr, "cannot map dumb buffer (%d): %m\n", errno);
	    r = -errno;
	    goto err_fb;
	}

	/* perform actual memory mapping */
	dev->map = mmap(0, dev->size, PROT_READ | PROT_WRITE, MAP_SHARED,
		        fd, mreq.offset);
	if (dev->map == MAP_FAILED) {
	    fprintf(stderr, "cannot mmap dumb buffer (%d): %m\n", errno);
	    r = -errno;
	    goto err_fb;
	}

	/* clear the framebuffer to 0 */
	memset(dev->map, 0, dev->size);

	return 0;

err_fb:
	drmModeRmFB(fd, dev->fb);
err_destroy:
	memset(&dreq, 0, sizeof(dreq));
	dreq.handle = dev->handle;
	drmIoctl(fd, DRM_IOCTL_MODE_DESTROY_DUMB, &dreq);
	return r;
}

int drmmodeset_setup_dev(int fd, drmModeRes *res, drmModeConnector *conn,
			     struct drmmodeset_dev *dev)
{
	int r;

	/* check if a monitor is connected */
	if (conn->connection != DRM_MODE_CONNECTED) {
	    fprintf(stderr, "ignoring unused connector %u\n", conn->connector_id);
	    return -ENOENT;
	}

	/* check if there is at least one valid mode */
	if (conn->count_modes == 0) {
	    fprintf(stderr, "no valid mode for connector %u\n", conn->connector_id);
	    return -EFAULT;
	}

	/* copy the mode information into our device structure */
	memcpy(&dev->mode, &conn->modes[0], sizeof(dev->mode));
	dev->width = conn->modes[0].hdisplay;
	dev->height = conn->modes[0].vdisplay;
	fprintf(stderr, "mode for connector %u is %ux%u\n",
		conn->connector_id, dev->width, dev->height);

	/* find a crtc for this connector */
	r = drmmodeset_find_crtc(fd, res, conn, dev);
	if (r) {
	    fprintf(stderr, "no valid crtc for connector %u\n", conn->connector_id);
	    return r;
	}

	/* create a framebuffer for this CRTC */
	r = drmmodeset_create_fb(fd, dev);
	if (r) {
	    fprintf(stderr, "cannot create framebuffer for connector %u\n", conn->connector_id);
	    return r;
	}

	return 0;
}


int drmmodeset_prepare(int fd)
{
	drmModeRes *res;
	drmModeConnector *conn;
	unsigned int i;
	struct drmmodeset_dev *dev;
	int r;

	/* retrieve resources */
	res = drmModeGetResources(fd);
	if (!res) {
	    fprintf(stderr, "cannot retrieve DRM resources (%d): %m\n", errno);
	    return -errno;
	}

	/* iterate all connectors */
	for (i = 0; i < res->count_connectors; ++i) {
	    /* get information for each connector */
	    conn = drmModeGetConnector(fd, res->connectors[i]);
	    if (!conn) {
		fprintf(stderr, "cannot retrieve DRM connector %u:%u (%d): %m\n",
				i, res->connectors[i], errno);
		continue;
	    }

	    /* create a device structure */
	    dev = malloc(sizeof(*dev));
	    if (!dev) {
		fprintf(stderr, "Can't allocate device structure (%d): %m\n", errno);
		continue;
	    }
	    memset(dev, 0, sizeof(*dev));
	    dev->conn = conn->connector_id;

	    /* call helper function to prepare this connector */
	    r = drmmodeset_setup_dev(fd, res, conn, dev);
	    if (r) {
		if (r != -ENOENT) {
		    errno = -r;
		    fprintf(stderr, "cannot setup device for connector %u:%u (%d): %m\n",
					i, res->connectors[i], errno);
		}
		free(dev);
		drmModeFreeConnector(conn);
		continue;
	    }

	    /* free connector data and link device into global list */
	    drmModeFreeConnector(conn);
	    dev->next = drmmodeset_list;
	    drmmodeset_list = dev;
	}

	/* free resources again */
	drmModeFreeResources(res);
	return 0;
}

void drmmodeset_cleanup(int fd)
{
	struct drmmodeset_dev *iter;
	struct drm_mode_destroy_dumb dreq;

	while (drmmodeset_list) {
	    /* remove from global list */
	    iter = drmmodeset_list;
	    drmmodeset_list = iter->next;

	    /* restore saved CRTC configuration */
	    drmModeSetCrtc(fd, iter->saved_crtc->crtc_id,
			       iter->saved_crtc->buffer_id,
			       iter->saved_crtc->x,
			       iter->saved_crtc->y,
			       &iter->conn,
			       1,
			       &iter->saved_crtc->mode);
	    drmModeFreeCrtc(iter->saved_crtc);

	    /* unmap buffer */
	    munmap(iter->map, iter->size);

	    /* delete framebuffer */
	    drmModeRmFB(fd, iter->fb);

	    /* delete dumb buffer */
	    memset(&dreq, 0, sizeof(dreq));
	    dreq.handle = iter->handle;
	    drmIoctl(fd, DRM_IOCTL_MODE_DESTROY_DUMB, &dreq);

	    /* free allocated memory */
	    free(iter);
	}
}

void drmmodeset_close(int fd)
{
    close(fd);
}


#endif	    // API_DRM


/***
 *
 *  FB specifics
 *
 ***/
#if API_FB

int fb_open(const char *node)
{
	int fd, r;
	struct drmmodeset_dev *dev;
	struct fb_var_screeninfo vinfo;
	struct fb_fix_screeninfo finfo;

	// open dev
	fd = open(node, O_RDWR | O_CLOEXEC);
	if (fd < 0) {
	    fprintf(stderr, "cannot open '%s' (%d): %m\n", node, errno);
	    return(-errno);
	}

	// Get fixed screen information
	if (ioctl(fd, FBIOGET_FSCREENINFO, &finfo) == -1) {
	    fprintf(stderr, "Error reading fixed information (%d): %m\n", errno);
	    close(fd);
	    return(-errno);
	}

	// Get variable screen information
	if (ioctl(fd, FBIOGET_VSCREENINFO, &vinfo) == -1) {
	    fprintf(stderr, "Error reading variable information (%d): %m\n", errno);
	    close(fd);
	    return(-errno);
	}

	//
	// Check whether we can support this screen
	// Future: we should also note whether the pixel
	// format is BGR or RGB, and whether 24 or 24+8 bits;
	// but most display hardware is BGR+pad.
	if (finfo.visual != FB_VISUAL_TRUECOLOR
	 || finfo.type	 != FB_TYPE_PACKED_PIXELS) {
	    fprintf(stderr, "Screen format not supported\n");
	    close(fd);
	    return(-EOPNOTSUPP);
	}

	//
	// Create a device structure
	dev = malloc(sizeof(*dev));
	if (!dev) {
	    fprintf(stderr, "Can't allocate device structure (%d): %m\n", errno);
	    close(fd);
	    return(-ENOMEM);
	}
	memset(dev, 0, sizeof(*dev));
	dev->width  = vinfo.xres;
	dev->height = vinfo.yres;
	dev->stride = finfo.line_length;
	dev->size   = vinfo.xres * vinfo.yres * vinfo.bits_per_pixel / 8;

	// Map memory
	dev->map = mmap(0, dev->size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, finfo.mmio_start);
	if (dev->map == MAP_FAILED) {
	    fprintf(stderr, "cannot mmap buffer (%d): %m\n", errno);
	    free(dev);
	    close(fd);
	    return(-errno);
	}

	// Done
	drmmodeset_list = dev;
	return(fd);
}

int fb_close(int fd)
{
    if (drmmodeset_list->map)
	munmap(drmmodeset_list->map, drmmodeset_list->size);
    if (drmmodeset_list) {
	free(drmmodeset_list);
	drmmodeset_list = NULL;
    }
    close(fd);
    return(0);
}

#endif	    // API_FB


/***
 *
 * Render image in the PIXCI frame buffer to
 * to the display hardware via DRM-KMS or FBDEV.
 *
 ***/
int image_display(pxbuffer_t buf)
{

    //
    // Compute video & display rates?
    // Dsplaying them, in full screen mode,
    // is a different problem, below.
    #if 1
	static	struct	    timeval otimeval = {0};
	static	uint32	    odisplay_count = 0;
	static	pxvbtime_t  ovbtime = 0;
		struct	    timeval ntimeval;
		pxvbtime_t  vbtime;

	gettimeofday(&ntimeval, NULL);
	ulong nt = ntimeval.tv_sec*1000L + (ntimeval.tv_usec+1000/2)/1000;
	ulong ot = otimeval.tv_sec*1000L + (otimeval.tv_usec+1000/2)/1000;

	vbtime = pxd_videoFieldCount(UNITSMAP);

	if (ot == 0) {
	    otimeval = ntimeval;
	    ot = nt;
	}
	if ((nt-ot) >= 1000) {
	    video_rate	 = 1000*(vbtime-ovbtime)/ (double)(nt-ot);
	    display_rate = 1000*(display_count-odisplay_count)/(double)(nt-ot);

	    odisplay_count = display_count;
	    otimeval = ntimeval;
	    ovbtime  = vbtime;
	}
    #endif

    #if USE_PXIPL
    {
	struct	    drmmodeset_dev *iter = drmmodeset_list;
	pximage_s   display;
	pxy_s	    dim = {display_wind.se.x, display_wind.se.y};
	int	    r;


	//
	// show video rate & display rate?
	// it is a shame to have to expend effort writing
	// the text into the image; but w/out a GUI or separate
	// console - there is no choice.
	#if 1
	    char    textbuffer[100];
	    uint    back[] = {0, 0, 0, 0};
	    uint    fore[] = {255, 255, 255, 255 };
	    pxy_s   pos = {10, 100};

	    snprintf(textbuffer, sizeof(textbuffer)-1, "video: %f fps  display: %f fps", video_rate, display_rate);
	    textbuffer[sizeof(textbuffer)-1] = 0;	// be safe
	    pxip8_drawchars3(NULL, pxd_defineImage(UNITSMAP, buf, 0, 0, -1, -1, "BGRx"),
				&pos, 0.0, textbuffer, strlen(textbuffer),
				10, 10, 2, 2, 's', fore, back, NULL, NULL);

	#endif

	//
	// Build a memory pximage to represent and access
	// the display frame buffer.
	// Future: prebuild once and save for future use.
	r = pximage_memory(&display, iter->map, &dim, iter->stride, PXDATUCHAR, 8, 4, PXHINTBGRX, 0);
	if (r < 0) {
	    fprintf(stderr, "cannot create pximage_memory: %s\n", pxd_mesgErrorCode(r));
	    return(r);
	}

	//
	// Render
	// Future: do pxd_defineImage once (for each buffer) and save
	// for future use.
	r = pxio8_vgadisplay(NULL,
			     pxd_defineImage(UNITSMAP, buf, 0, 0, -1, -1, pxd_imageCdim()==1? "Grey": "BGRx"),
			     NULL, 0, 'n', 0, 0, &display, NULL, NULL);
	if (r < 0) {
	    fprintf(stderr, "cannot render via pxio8_vgadisplay: %s\n", pxd_mesgErrorCode(r));
	    return(r);
	}

	display_count++;
    }
    #endif
    #if USE_PIXELCOPY
	if (rgbbuf) {
	    struct drmmodeset_dev *iter = drmmodeset_list;
	    uint j;
	    uchar *pixp = (uchar*) rgbbuf;
	    pxd_readuchar(UNITSMAP, buf, 0, 0, display_width, display_height, rgbbuf, rgbbufsize, "BGRx");
	    for (j = 0; j < display_height; j++) {
		memcpy(&iter->map[iter->stride*j], pixp, display_width*4);
		pixp += display_width*4;
	    }
	}
	display_count++;
    #endif

    return(0);
}


int main(int argc, char **argv)
{
	int r;
	int apifd;
	struct termios termios, otermios;

	/*
	 * Open PIXCI
	 * Either FORMAT or FORMATFILE or FORMATFILEARG
	 * should have been selected above.
	 */
	#if defined(FORMAT)
	    r = pxd_PIXCIopen(DRIVERPARMS, FORMAT, "");
	#elif defined(FORMATFILE)
	    r = pxd_PIXCIopen(DRIVERPARMS, "", FORMATFILE);
	#elif defined(FORMATFILEARG)
	    if (argc < 2) {
		fprintf(stderr, "Missing command line parameter\n");
		return(1);
	    }
	    // i.e. invoked as 'xclibel8 pathname'
	    r = pxd_PIXCIopen(DRIVERPARMS, "", argv[1]);
	#else
	    #error "Select a video format or a video format file"
	#endif
	if (r >= 0) {
	    printf("Open PIXCI\n" );	// success!
	} else {
	    printf("Open PIXCI Error %d\a\a\n", r);
	    pxd_mesgFault(UNITSMAP);	// to stdout
	    return(1);
	}
	// we want to do live, dual buffer capture.
	// warn if there is only one buffer
	if (pxd_imageZdim() < 2) {
	    printf("Warning: Only one PIXCI frame buffer\n");
	}

	/*
	 * Open the DRM device
	 */
	#if API_DRM
	{
	    struct drmmodeset_dev *drmiter;

	    r = apifd = drmmodeset_open(DRM_DEVCARD);
	    if (apifd < 0)
		goto done1;

	    /* prepare all DRM connectors and CRTCs */
	    r = drmmodeset_prepare(apifd);
	    if (r)
		goto done2;

	    /* perform actual DRM modesetting on each found connector+CRTC */
	    for (drmiter = drmmodeset_list; drmiter; drmiter = drmiter->next) {
		drmiter->saved_crtc = drmModeGetCrtc(apifd, drmiter->crtc);
		r = drmModeSetCrtc(apifd, drmiter->crtc, drmiter->fb, 0, 0,
				     &drmiter->conn, 1, &drmiter->mode);
		if (r)
		    fprintf(stderr, "cannot set CRTC for connector %u (%d): %m\n",
			drmiter->conn, errno);
	    }
	}
	#endif

	/*
	 * Open the FB device
	 */
	#if API_FB
	    r = apifd = fb_open(FB_DEVCARD);
	    if (apifd < 0)
		goto done1;
	#endif

	/*
	 * Now that the PIXCI & DRM/FB are open,
	 * configure the image display resolution and buffers.
	 */
	#if USE_PXIPL
	{
	    double	scalex, scaley, aspect;
	    // If using PXIPL for display: aspect ratio can
	    // be corrected and the image resize.
	    display_wind.nw.x = 0;
	    display_wind.nw.y = 0;
	    display_wind.se.x = drmmodeset_list->width;
	    display_wind.se.y = drmmodeset_list->height;

	    aspect = pxd_imageAspectRatio();
	    if (aspect == 0.0)
		aspect = 1.0;
	    scalex = display_wind.se.x/(double)pxd_imageXdim();
	    scaley = display_wind.se.y/((double)pxd_imageYdim()*aspect);
	    scalex = MIN(scalex, scaley);
	    display_wind.se.x = (int)(pxd_imageXdim() * scalex);
	    display_wind.se.y = (int)(pxd_imageYdim() * scalex * aspect);

	    // Force display width & height, limited only by
	    // max screen width & height, and not corrected for
	    // aspect ratio.
	    if (PXIPL_DISPLAY_WIDTH)
		display_wind.se.x = MIN(PXIPL_DISPLAY_WIDTH, drmmodeset_list->width);
	    if (PXIPL_DISPLAY_HEIGHT)
		display_wind.se.y = MIN(PXIPL_DISPLAY_HEIGHT, drmmodeset_list->height);

	    display_width  = display_wind.se.x;
	    display_height = display_wind.se.y;
	}
	#endif
	#if USE_PIXELCOPY
	    // The captured image isn't resized,
	    // nor aspect ratio corrected. Use same dimensions as captured
	    // image, but not larger than the desktop.
	    display_width  = MIN( pxd_imageXdim(), drmmodeset_list->width);
	    display_height = MIN( pxd_imageYdim(), drmmodeset_list->height);
	    // Allocate a local image buffer for display.
	    rgbbufsize = display_width * display_height * 4;
	    rgbbuf = malloc(rgbbufsize);
	    if (!rgbbuf) {
		fprintf(stderr, "Can't allocate rgb buffer (%d): %m\n", errno);
		r = -ENOMEM;
		goto done3;
	    }

	#endif
	printf("image:        \t %d x %d\n", pxd_imageXdim(), pxd_imageYdim());
	printf("image display:\t %d x %d\n", display_width, display_height);

	/*
	 * Start live capture, dual buffer
	 */
	r = pxd_goLivePair(UNITSMAP, 1, MIN(2, pxd_imageZdim()));

	//
	// Setup the keyboard input (stdin)
	// so we can probe for characters w/out blocking.
	// And without echoing onto the display.
	//
	tcgetattr(0, &termios);
	otermios = termios;
	termios.c_cc[VMIN] = termios.c_cc[VTIME] = 0;
	termios.c_lflag &= ~(ICANON|ECHO);
	tcsetattr(0, TCSANOW, &termios);

	//
	// Wait for a captured image, then display same.
	// This uses simple polling.
	// Break when any key is typed.
	{
	    pxbuffer_t obuf  = pxd_capturedBuffer(UNITSMAP);
	    pxvbtime_t otime = pxd_capturedFieldCount(UNITSMAP);
	    for (; getchar() == -1; ) {
		pxbuffer_t buf = pxd_capturedBuffer(UNITSMAP);
		pxvbtime_t time = pxd_capturedFieldCount(UNITSMAP);
		// just comparing "buf != obuf" would be sufficient
		// if there are at least two frame buffers.
		// But if there is a single frame buffer ...
		if (time != otime) {
		    #if API_DRM | API_FB
			image_display(buf);
		    #endif
		    obuf  = buf;
		    otime = time;
		    continue;
		}
		// nothing to do for now
		usleep(5000);

		//
		// If the camera is disconnected, capture will stop.
		// In some applications, that might be worthy of an
		// error report. Here, we simply restart capture.
		//
		if (pxd_goneLive(UNITSMAP, 0) == 0)
		    pxd_goLivePair(UNITSMAP, 1, MIN(2, pxd_imageZdim()));
	    }
	}

	r = 0;

	/*
	 * Cleanup everything, in reverse order.
	 * Technically, we don't have to stop capture,
	 * closing XCLIB will do that; just being neat.
	 */
	pxd_goUnLive(UNITSMAP);
	pxd_mesgFault(UNITSMAP);

	tcsetattr(0, TCSANOW, &otermios);

	#if USE_PIXELCOPY
	    if (rgbbuf)
		free(rgbbuf);
	#endif


	#if API_FB
done3:	    fb_close(apifd);
	#endif

	#if API_DRM
done3:
	    drmmodeset_cleanup(apifd);
done2:
	    drmmodeset_close(apifd);
	#endif
done1:

	//
	// With DRM/FB disabled, we can printf the
	// display and video rate as simple text
	// and expect it to be seen.
	// We also re-output dimensions, as the previous info
	// may have been overwritten by the image.
	if (r == 0) {
	    fprintf(stderr, "image:        \t %d x %d\n", pxd_imageXdim(), pxd_imageYdim());
	    fprintf(stderr, "image display:\t %d x %d\n", display_width, display_height);
	    fprintf(stderr, "video: %f fps  display: %f fps\n", video_rate, display_rate);
	    if (pxd_imageZdim() < 2)
		printf("Warning: Only one PIXCI frame buffer\n");
	}

	pxd_PIXCIclose();


	fprintf(stderr, "exiting\n");
	return r;
}

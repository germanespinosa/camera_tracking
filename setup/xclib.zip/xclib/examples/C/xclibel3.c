/*
 *
 *	xclibel3.c	External	25-Feb-2020
 *
 *	Copyright (C)  2004-2018  EPIX, Inc.  All rights reserved.
 *
 *	Example program for XCLIB C Library, SCF Level functions.
 *	Assumes GTK+2.0 libraries installed. See http://www.gtk.org
 *
 *	Has GUI controls for PIXCI(R) SV2/SV3/SV4/SV5/SV5A/SV5B/SV5L/SV7/SV8/A110/A310.
 *	Can be used with other PIXCI(R) frame grabbers,
 *	altho some controls may be meaningless.
 *
 *	Demonstrates XCLIB and/or PXIPL functions for capture and
 *	display of imagery and graphics.
 *	This Linux GTK program must, of course, also make use of
 *	various Linux GTK functions; however, this is not
 *	intended to serve as a GTK tutorial.
 *
 */


/*
 *  INSTRUCTIONS:
 *
 *  1)	Set 'define' options below according to the intended camera
 *	and video format.
 *
 *	For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV5L, and SV6 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, or PAL/YC.
 *	(The SV5A and SV5B do not support NTSC/YC or PAL/YC).
 *	For PIXCI(R) SV7 frame grabbers
 *	common choices are RS-170, NSTC, CCIR, or PAL.
 *	For PIXCI(R) SV8 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, PAL/YC.
 *	For PIXCI(R) A110 frame grabbers
 *	common choices are RS-170, CCIR and others, see below.
 *	For PIXCI(R) A310 frame grabbers
 *	common choices are RS-170, CCIR and others, see below.
 *
 *	For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32, D2X, D3X, D3XE,
 *	E1, E1DB, E4, E4DB, E4G2, E4TX2, E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-PoCL,
 *	EB1mini, miniH2b, miniH2, EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB, ELS2, SI, SI1, SI2, and SI4
 *	frame grabbers, use "default" to select the default format for the camera
 *	for which the PIXCI(R) frame grabber is intended.
 *	For non default formats, use XCAP to save the video set-up to a
 *	file, and set FORMAT to the saved file's name.
 *	For camera's with RS-232 control, note that the saved
 *	video set-up only resets the PIXCI(R) frame grabber's
 *	settings, but XCLIB does not reset the camera's settings.
 *	For selected Camera Link cameras w. serial controls,
 *	the video setup file may include serial commands which are
 *	automatically sent by XCLIB to the camera.
 *
 *	Alternately, this could be modified to use any
 *	other convention chosen by the programmer to allow
 *	run time selection of the video format and resolution.
 *
 */

#if !defined(FORMAT) && !defined(FORMATFILE)
				  // For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV5L, SV6
  //#define FORMAT  "RS-170"	  // RS-170 on input 2
  //#define FORMAT  "NTSC"	  // NTSC on input 2
  //#define FORMAT  "NTSC/YC"	  // NSTC S-Video on input 1		  (N/A on SV5A,SV5B)
  //#define FORMAT  "CCIR"	  // CCIR on input 2
  //#define FORMAT  "PAL"	  // PAL (B,D,G,H,I) on input 2
  //#define FORMAT  "PAL/YC"	  // PAL (B,D,G,H,I) S-Video on input 1   (N/A on SV5A,SV5B)
  //#define FORMAT  "default"	  // NSTC S-Video on input 1

				  // For PIXCI(R) SV7
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "NTSC"	  // NTSC
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "PAL"	  // PAL
  //#define FORMAT  "default"	  // NSTC

				  // For PIXCI(R) SV8
  //#define FORMAT  "RS-170"	  // RS-170 on BNC 0
  //#define FORMAT  "NTSC"	  // NTSC on BNC 0
  //#define FORMAT  "NTSC/YC"	  // NSTC S-Video
  //#define FORMAT  "CCIR"	  // CCIR on BNC 0
  //#define FORMAT  "PAL"	  // PAL on BNC 0
  //#define FORMAT  "PAL/YC"	  // PAL (B,D,G,H,I) S-Video
  //#define FORMAT  "default"	  // NSTC on BNC 0

				  // For PIXCI(R) A310
  //#define FORMAT  "default"	  // as preset in board's eeprom
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "Video 720x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 720x480i 60Hz RGB"
  //#define FORMAT  "Video 720x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 720x576i 50Hz RGB"
  //#define FORMAT  "Video 640x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 640x480i 60Hz RGB"
  //#define FORMAT  "Video 768x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 768x576i 50Hz RGB"
  //#define FORMAT  "Video 1920x1080i 60Hz"
  //#define FORMAT  "Video 1920x1080i 60Hz RGB"
  //#define FORMAT  "Video 1920x1080i 50Hz"
  //#define FORMAT  "Video 1920x1080i 50Hz RGB"
  //#define FORMAT  "Video 1920x1080p 60Hz"
  //#define FORMAT  "Video 1920x1080p 60Hz RGB"
  //#define FORMAT  "Video 1920x1080p 50Hz"
  //#define FORMAT  "Video 1920x1080p 50Hz RGB"
  //#define FORMAT  "Video 1280x720p 50Hz"
  //#define FORMAT  "Video 1280x720p 50Hz RGB"
  //#define FORMAT  "Video 1280x720p 60Hz"
  //#define FORMAT  "Video 1280x720p 60Hz RGB"
  //#define FORMAT  "SVGA 800x600 60Hz RGB"
  //#define FORMAT  "SXGA 1280x1024 60Hz RGB"
  //#define FORMAT  "VGA 640x480 60Hz RGB"
  //#define FORMAT  "XGA 1024x768 60Hz RGB"
  //#define FORMAT  "RS343 875i 60Hz"
  //#define FORMAT  "RS343 875i 60Hz RGB"

				  // For PIXCI(R) A110
  //#define FORMAT  "default"	  // as preset in board's eeprom
  //#define FORMAT  "RS-170"	  // RS-170
  //#define FORMAT  "CCIR"	  // CCIR
  //#define FORMAT  "Video 720x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 720x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 640x480i 60Hz"	// RS-170
  //#define FORMAT  "Video 768x576i 50Hz"	// CCIR
  //#define FORMAT  "Video 1920x1080i 60Hz"
  //#define FORMAT  "Video 1920x1080i 50Hz"
  //#define FORMAT  "Video 1920x1080p 60Hz"
  //#define FORMAT  "Video 1920x1080p 50Hz"
  //#define FORMAT  "Video 1280x720p 50Hz"
  //#define FORMAT  "Video 1280x720p 60Hz"
  //#define FORMAT  "RS343 875i 60Hz"

				  // For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32,
				  // D2X, D3X, D3XE, E1, E1DB, E4, E4DB, E4G2, E4TX2,
				  // E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-POCL, EB1mini, miniH2b, miniH2,
				  // EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB,
				  // ELS2, SI, SI1, SI2, SI4
  //#define FORMAT  "default"	  // as per board's intended camera

					  // For any PIXCI(R) frame grabber:
    #define FORMAT	  "default"	  // as per board's default camera or video format
  //#define FORMATFILE	  "xcvidset.fmt"  // using format file saved by XCAP
#endif


/*
 *  2.1) Set number of expected PIXCI(R) frame grabbers.
 *  The XCLIB Simple 'C' Functions expect that the boards are
 *  identical and operated at the same resolution.
 *
 *  For PIXCI(R) frame grabbers with multiple, functional units,
 *  the XCLIB presents the two halves of the PIXCI(R) E1DB, E4DB, E4G2-2F, E4TX2-2F,
 *  E8CAM, E8DB, e104x4-2f, ECB2, EL1DB, ELS2, miniH2b, SI2, or SV7 frame grabbers,
 *  or the three parts of the PIXCI(R) E4G2-F2B, E4TX2-F2B, or e104x4-f2b frame grabber,
 *  or the four quarters of the PIXCI(R) E4G2-4B, E4TX2-4B, e104x4-4b, or SI4 frame grabbers,
 *  as two, three, or four independent PIXCI(R) frame grabbers, respectively.
 *
 *  This example expects only one unit.
 */
#if !defined(UNITS)
    #define UNITS	1
#endif
#define UNITSMAP    ((1<<UNITS)-1)  // shorthand - bitmap of all units


/*
 *  2.2) Optionally, set driver configuration parameters.
 *  These are normally left to the default, "".
 *  The actual driver configuration parameters include the
 *  desired PIXCI(R) frame grabbers, but to make configuation easier,
 *  code, below, will automatically add board selection to this.
 *
 *  Note: Under Linux, the image frame buffer memory can't be set as
 *  a run time option. It MUST be set via insmod so the memory can
 *  be reserved during Linux's initialization.
 */
#if !defined(DRIVERPARMS)
  //#define DRIVERPARMS "-QU 0"       // don't use interrupts
  //#define DRIVERPARMS "-IM 8192"    // request 8192 mbyte of frame buffer memory
    #define DRIVERPARMS ""	      // default
#endif

/*
 *  3.1)  Choose whether the optional PXIPL Image Processing Library
 *	is available, and some PXIPL functions should be demonstrated.
 *
 *	This also selects the API for image display.
 *	The USE_PXIPL or USE_PXIPL_THREADS option supports arbitrary
 *	image resizing;
 *	other options render each image pixel as one display pixel.
 */
#if  !defined(USE_PXIPL) && !defined(USE_PXIPL_THREADS) \
  && !defined(USE_X11) && !defined(USE_GDK)
    #define USE_PXIPL		    0	// Use PXIPL for image display
    #define USE_PXIPL_THREADS	    0	// Use PXIPL w. N threads for image display
    #define USE_X11		    1	// Use raw X11 for image display
    #define USE_GDK		    0	// Use GDK for image display
#endif
#if !defined(PXIPL_MAXDISPLAY)
    #define PXIPL_MAXDISPLAY	1	// 1: use most of display area
					// 0: limit display width to image xdim
#endif
#if !defined(PXIPL_DISPLAY_WIDTH)|!defined(PXIPL_DISPLAY_HEIGHT)
    #define PXIPL_DISPLAY_WIDTH     0	// if not 0, force display area
    #define PXIPL_DISPLAY_HEIGHT    0	// to these sizes, even if there is
					// no room for anything else.
#endif
#if !defined(PXIPL_NTHREADS)
    #define PXIPL_NTHREADS	2
#endif

/*
 *  3.2) Select how display updates should be triggered.
 *  Only one of these choices should have value 1, the others should be 0.
 */
#if !defined(UPDATE_TIMER) && !defined(UPDATE_SIGNAL)
    #define UPDATE_TIMER    0	// Use timer to periodically poll library
				// and test for a new image to be displayed.
				// Simpler (?)
    #define UPDATE_SIGNAL   1	// Use a Signal to trigger display of new image.
				// Slightly more efficient.
#endif



/*
 *  4)	On some Linux distributions the GTK libraries must be explicitly installed:
 *
 *	    apt-get install gtk2.0
 *	or
 *	    apt-get install gtk+-2.0
 *
 *
 *  5)	Compile with GCC w/out PXIPL for 32 bit Linux on Intel i386 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/xclib_i386.a -o xclibel3 -lm `pkg-config gtk+-2.0 --libs`
 *    
 *	Compile with GCC with PXIPL or X11 for 32 bit Linux on Intel i386 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/pxipl_i386.a ../../lib/xclib_i386.a -o xclibel3 -lX11 -lm -lpthread `pkg-config gtk+-2.0 --libs`
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on Intel x86_64 as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/xclib_x86_64.a -o xclibel3 -lm `pkg-config gtk+-2.0 --libs`
 *    
 *	Compile with GCC with PXIPL or X11 for 64 bit Linux on Intel x86_64 as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/pxipl_x86_64.a ../../lib/xclib_x86_64.a -o xclibel3 -lX11 -lm -lpthread `pkg-config gtk+-2.0 --libs`
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/xclib_aarch64.a -o xclibel3 -lm `pkg-config gtk+-2.0 --libs`
 *
 *	Compile with GCC with PXIPL or X11 for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/pxipl_aarch64.a ../../lib/xclib_aarch64.a -o xclibel3 -lX11 -lm -lpthread `pkg-config gtk+-2.0 --libs`
 *
 *	Compile with GCC w/out PXIPL for 32 bit Linux on nVidia/ARM TK1
 *	or Boundary Devices/ARM NITROGEN6 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/xclib_armv7l.a -o xclibel3 -lm `pkg-config gtk+-2.0 --libs`
 *
 *	Compile with GCC with PXIPL or X11 for 32 bit Linux on nVidia/ARM TK1
 *	or Boundary Devices/ARM NITROGEN6 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc `pkg-config gtk+-2.0 --cflags` -no-pie xxclibel3.c ../../lib/pxipl_armv7l.a ../../lib/xclib_armv7l.a -o xclibel3 -lX11 -lm -lpthread `pkg-config gtk+-2.0 --libs`
 *
 *	Run as:
 *	    ./xclibel3
 *
 */


/*
 *  NECESSARY INCLUDES:
 */
#include <stdio.h>		// c library
#include <signal.h>		// c library
#include <stdlib.h>		// c library
#include <stdarg.h>		// c library
#include <sys/time.h>		// c library
#include "xcliball.h"		// XCLIB function prototypes
#if USE_PXIPL | USE_PXIPL_THREADS
  #include "pxipl.h"		// PXIPL function prototypes
  #include "pthread.h"
#endif
#if USE_X11
#endif
#include <gtk/gtk.h>		// GTK Window Library
#include <gdk/gdkx.h>


/* 
 * GTK Image Window and Status Bar and Global Variables
 */
GtkWidget   *display_area;
GtkWidget   *image_buffer_display;
GtkWidget   *field_count_display;
GtkWidget   *display_rate_display;
gboolean    update_window = FALSE;
guint	    display_count = 0;	    // display count / rate
pxvbtime_t  lastcapttime = 0;	    // when was image last captured - in video fields

/*
 * Our capture modes & flags
 */
#define     LIVE_LIVE	'l'	    // live verbs
#define     LIVE_SNAP	'S'
#define     LIVE_PAIR	'L'
#define     SNAP_SNAP	's'
int	    liveon = 0; 	    // current video capture mode

/*
 * Display area, image buffer, and associated variables.
 */
gint	    display_width;
gint	    display_height;
#if USE_PXIPL | USE_PXIPL_THREADS
  pxywindow_s	display_wind;		    // display area
  pximage_s	*pximage1[PXIPL_NTHREADS];  // frmae buffer 1 access, for each thread
  pximage_s	*pximage2[PXIPL_NTHREADS];  // frmae buffer 2 access, for each thread
  void		*x11state = NULL;
#elif USE_X11
  Display   *x11Display;
  Drawable  x11Drawable;
  XImage    *x11Ximage = NULL;
  Visual    *x11Visual;
  guchar    *rgbbuf = NULL;	// image buffer
  size_t    rgbbufsize; 	// size of buffer
#elif USE_GDK
  guchar    *rgbbuf = NULL;	// GTK image buffer
  size_t    rgbbufsize; 	// size of buffer
#endif

/*
 * Need synchronization if using async signals.
 */
#if UPDATE_SIGNAL
pthread_mutex_t    signal_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif


/*
 * Avoid repeated checks for ...
 */
gboolean    PIXCI_is_SV2345678 = FALSE;
gboolean    PIXCI_is_AX10      = FALSE;

/*
 * To improve readability when translating parameters,
 * such as gain, offset, etc., to/from scrollbar controls.
 */
#define ToScroll(Value, LoV, HiV)   (int)(((Value)-(LoV))*100./((HiV)-(LoV)))
#define UnScroll(Scroll, LoV, HiV)  ((LoV)+(double)(Scroll)*((HiV)-(LoV))/100.)



/*
 *  SUPPORT STUFF:
 *
 *  Catch CTRL+C and floating point exceptions so that once
 *  opened, the PIXCI(R) library is always closed before exit.
 *  In some environments, this isn't critical; the operating system
 *  advises the PIXCI(R) driver that the program has terminated.
 *  In other environments, the operating system isn't as helpful
 *  and the driver would be left open.
 */
static void signaled(int sig)
{
    /*
     * Some languages/environments don't allow
     * use of printf from a signal catcher.
     * Printing the message isn't important anyhow.
     *
    if (sig == SIGINT)
	printf("Break\n");
    if (sig == SIGFPE)
	printf("Float\n");
    */

    pxd_PIXCIclose();
    exit(1);
}


/*
 * Open the XCLIB C Library for use.
 */
static int do_open(void)
{
    int i;

    //
    // Either FORMAT or FORMATFILE should have been
    // selected above.
    //
    #if defined(FORMAT)
	i = pxd_PIXCIopen(DRIVERPARMS, FORMAT, "");
    #elif defined(FORMATFILE)
	i = pxd_PIXCIopen(DRIVERPARMS, "", FORMATFILE);
    #else
	#error "Select a video format or a video format file"
    #endif
    if (i >= 0) {
	g_print("Open PIXCI\n" );   // success!
    } else {
	#if 0	// message to stdout/stderr?
	    printf("Open Error %d\a\a\n", i);
	    pxd_mesgFault(UNITSMAP);
	#else	// or message via dialog?
	{
	    GtkWidget  *dialog;
	    char buf[1024] = {0};   // default as empty string
	    pxd_mesgFaultText(UNITSMAP, buf, sizeof(buf));
	    dialog = gtk_message_dialog_new(NULL,
					    GTK_DIALOG_DESTROY_WITH_PARENT,
					    GTK_MESSAGE_ERROR,
					    GTK_BUTTONS_CLOSE,
					    "Open error %s(%d)\n\n%s", pxd_mesgErrorCode(i), i, buf);
	    if (dialog) {
		gtk_dialog_run(GTK_DIALOG (dialog));	// display as modal
		gtk_widget_destroy(dialog);
	    }
	}
	#endif
    }
    //
    // We provide additional controls
    // for analog frame grabbers, check
    // frame grabber model.
    //
    switch (pxd_infoModel(UNITSMAP)) {
      case PIXCI_SV2:
      case PIXCI_SV3:
      case PIXCI_SV4:
      case PIXCI_SV5:
      case PIXCI_SV6:
      case PIXCI_SV7:
      case PIXCI_SV8:
	PIXCI_is_SV2345678 = TRUE;
	break;
      case PIXCI_A310:
      case PIXCI_A110:
      case PIXCI_A1107I1O:
	PIXCI_is_AX10 = TRUE;
	break;
    }
    return(i);
}

/*
 * Close the PIXCI(R) frame grabber
 */
static void do_close()
{
    g_print("Close PIXCI\n");
    pxd_PIXCIclose();
}


/*
 * Utilities for SV2/3/4/5/7/8 and A110/A310.
 * Get/set current brightness and gain/contrast.
 * These translate the XCLIB's generic floating, scaled,
 * values to integers between 0 & 100, so they will be
 * useful for scroll bars. Same as in XCLIBEX2.CPP
 */
static int getBright()
{
    switch (pxd_infoModel(UNITSMAP)) {
      case PIXCI_SV8:
	return(ToScroll(pxd_getBrightness(1), -100.0, 100.0));
      case PIXCI_SV7:
      //return((int)(50+pxd_getBrightness(1)*100/(76*2)));
	return(ToScroll(pxd_getBrightness(1), -76.22, 75.64));
      case PIXCI_A310:
      case PIXCI_A110:
      case PIXCI_A1107I1O:
	return(ToScroll(pxd_getAdcOffsetA(1), -124/1024., 124/1024.));
      default:
	//return((int)(pxd_getBrightness(1)+50));
	return(ToScroll(pxd_getBrightness(1), -50.0, 49.61));
    }
}
static void setBright(int b)
{
    int err = 0;
    switch (pxd_infoModel(UNITSMAP)) {
      case PIXCI_SV8:
	err = pxd_setContrastBrightness(UNITSMAP, pxd_getContrast(1), UnScroll(b, -100.0, 100.0));
	break;
      case PIXCI_SV7:
      //err = pxd_setContrastBrightness(UNITSMAP, pxd_getContrast(1), (b-50)*76*2/100);
	err = pxd_setContrastBrightness(UNITSMAP, pxd_getContrast(1), UnScroll(b, -76.22, 75.64));
	break;
      case PIXCI_A310:
      case PIXCI_A110:
      case PIXCI_A1107I1O:
	err = pxd_setAdcGainOffset(UNITSMAP, 0, pxd_getAdcGainA(1), UnScroll(b, -124/1024., 124/1024.), pxd_getAdcGainB(1), pxd_getAdcOffsetB(1));
	break;
      default:
      //err = pxd_setContrastBrightness(UNITSMAP, pxd_getContrast(1), b-50);
	err = pxd_setContrastBrightness(UNITSMAP, pxd_getContrast(1), UnScroll(b, -50.0, 49.61));
	break;
    }
}
static int getGain()
{
    switch (pxd_infoModel(UNITSMAP)) {
      case PIXCI_SV8:
	return(ToScroll(pxd_getContrast(1), 0.0, 200.0));
      case PIXCI_SV7:
      //return((int)(pxd_getContrast(1)/2));
	return(ToScroll(pxd_getContrast(1), 0.0, 199.22));
      case PIXCI_A310:
      case PIXCI_A110:
      case PIXCI_A1107I1O:
	return(ToScroll(pxd_getAdcGainA(1), 0, 6));
      default:
      //return((int)(pxd_getContrast(1)*100./237.07));
	return(ToScroll(pxd_getContrast(1), 0.0, 237.07));
    }
}
static void setGain(int b)
{
    int err = 0;
    switch (pxd_infoModel(UNITSMAP)) {
      case PIXCI_SV8:
	err = pxd_setContrastBrightness(UNITSMAP, UnScroll(b, 0.0, 200.0), pxd_getBrightness(1));
	break;
      case PIXCI_SV7:
      //err = pxd_setContrastBrightness(UNITSMAP, b*2, pxd_getBrightness(1)*2);
	err = pxd_setContrastBrightness(UNITSMAP, UnScroll(b, 0.0, 199.22), pxd_getBrightness(1));
	break;
      case PIXCI_A310:
      case PIXCI_A110:
      case PIXCI_A1107I1O:
	err = pxd_setAdcGainOffset(UNITSMAP, 0, UnScroll(b, 0, 6), pxd_getAdcOffsetA(1), pxd_getAdcGainB(1), pxd_getAdcOffsetB(1));
	break;
      default:
      //err = pxd_setContrastBrightness(UNITSMAP, (b*237.07/100.), pxd_getBrightness(1));   // + 255 for rounding!
	err = pxd_setContrastBrightness(UNITSMAP, UnScroll(b, 0.0, 237.07), pxd_getBrightness(1));
    }
}


/* Refresh the displayed image */
static gboolean update_imagedisplay(gboolean force)
{

    pxvbtime_t lasttime = pxd_capturedFieldCount(1);
    if (lastcapttime != lasttime || force) {
	lastcapttime = lasttime;

	//
	// In most video modes, we are capturing
	// into buffer 1; in live pair, we alternate
	// and request which buffer has the most recent image.
	//
	pxbuffer_t buf = pxd_capturedBuffer(UNITSMAP);
	if (buf == 0)	// nothing ever captured?
	    buf = 1;


	#if USE_PXIPL | USE_PXIPL_THREADS
	{
	    /*
	     * Use PXIPL for Display - Requires PXIPL Library
	     * Performs image scaling into display window.
	     */
	    #if USE_PXIPL
		struct pximage	*pximage;
		pximage = pxd_defineImage(UNITSMAP, buf, 0, 0, -1, -1, "Display");
		pxio8_X11Display(NULL, pximage, NULL, 0, 'n', 0, 0, GDK_WINDOW_XDISPLAY(display_area->window),
		    GDK_DRAWABLE_XID(display_area->window) , 0, 0, &display_wind, NULL, NULL);
	    #else
		int	i;
		if (x11state == NULL) {
		    // precompute access to buffers 1 & 2; saving a bit of time later
		    for (i = 0; i < PXIPL_NTHREADS; i++) {
			pximage1[i] = pxd_definePximage(UNITSMAP, 1, 0, 0, -1, -1, "Display");
			pximage2[i] = pxd_definePximage(UNITSMAP, 2, 0, 0, -1, -1, "Display");
		    }
		    pxio9_X11Display2Init(PXIPL_NTHREADS, NULL, &x11state, pximage, NULL,
			0, 'n', 0, 0, GDK_WINDOW_XDISPLAY(display_area->window),
			GDK_DRAWABLE_XID(display_area->window) , 0, 0, &display_wind, NULL, NULL);
		    if (!x11state) {
			g_print("Can't init pxio9_X11Display2Init\n");
			return(FALSE);
		    }
		}
		if (x11state != NULL) {
		    pxio9_X11Display2Draw(PXIPL_NTHREADS, NULL, &x11state,
			buf==2?pximage2:pximage1, NULL, 0, 'n', 0, 0,
			&display_wind, NULL, NULL);
		}
	    #endif
	}
	#elif USE_X11
	    /*
	     * Use X11. These one time initializations couldn't
	     * be done earlier, during setup, as GDK hadn't yet
	     * set the display_area->window.
	     */
	    if (!x11Display) {
		x11Display = GDK_WINDOW_XDISPLAY(display_area->window);
		x11Drawable = GDK_DRAWABLE_XID(display_area->window);
		if (!x11Display) {
		    g_print("Can't get X11 Display\n");
		    return(FALSE);
		}
		x11Visual = XDefaultVisual(x11Display, XDefaultScreen(x11Display));
		if (!x11Visual) {
		    g_print("Can't get X11 Visual\n");
		    return(FALSE);
		}
		if (x11Visual->class != TrueColor
		 && x11Visual->class != DirectColor) {
		    g_print("Only supports X11 TrueColor or DirectColor\n");
		    return(FALSE);
		}
		if (XDisplayPlanes(x11Display, XDefaultScreen(x11Display)) != 24) {
		    g_print("Only supports X11 24 bits per pixel\n");
		    return(FALSE);
		}
		x11Ximage = XCreateImage(x11Display, x11Visual,
				    24,   // depth
				    ZPixmap,
				    0,	  // offset. pixels ignored at start of line
				    rgbbuf, display_width, display_height,
				    32,   // bitmap_pad. quantum of scanline (8,16,32); scanline is integer mulltiple of ...
				    0);   // bytes per line
		if (!x11Ximage) {
		    g_print("Can't create X11 Ximage\n");
		    return(FALSE);
		}
	    }
	    if (rgbbuf)
		pxd_readuchar(UNITSMAP, buf, 0, 0, display_width, display_height, rgbbuf, rgbbufsize, "RGBx");
	    if (x11Ximage) {
		XPutImage(x11Display, x11Drawable, XDefaultGC(x11Display, XDefaultScreen(x11Display)),
			  x11Ximage, 0, 0, 0, 0,
			  display_width, display_height);
	    }
	#elif USE_GDK
	    /*
	     * Use GDK for Display
	     * Displays pixels one-to-one into graphics window
	     */
	    if (pxd_imageCdim() == 1) {
		pxd_readuchar(UNITSMAP, buf, 0, 0, display_width, display_height, rgbbuf, rgbbufsize, "GREY");
		gdk_draw_gray_image (display_area->window, display_area->style->fg_gc[GTK_STATE_NORMAL],
		    0, 0, display_width, display_height, GDK_RGB_DITHER_NONE, rgbbuf, display_width);
	    } else {
		pxd_readuchar(UNITSMAP, buf, 0, 0, display_width, display_height, rgbbuf, rgbbufsize, "RGB");
		gdk_draw_rgb_image (display_area->window, display_area->style->fg_gc[GTK_STATE_NORMAL],
		    0, 0, display_width, display_height, GDK_RGB_DITHER_NONE, rgbbuf, display_width * 3);
	    }
	#endif

	display_count++;

	return (TRUE);
    }

    return FALSE;
}


/* Snap an Image  popped via GTK */
static gboolean do_snap (GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{

    if (liveon) {
	pxd_goUnLive(UNITSMAP);
	liveon = 0;
	g_print("UnLive\n");
	return TRUE;
    }

    pxd_goSnap(UNITSMAP, 1L);
    g_print("Snap\n");

    return TRUE;
}

/* Toggle Live Display */
static gboolean do_live (GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{
    if (liveon) {
	pxd_goUnLive(UNITSMAP);
	liveon = 0;
	g_print("UnLive\n");
	return TRUE;
    }
    pxd_goLive(UNITSMAP, 1L);
    liveon = LIVE_LIVE;
    g_print("Live\n");
  
    return TRUE;
}

/* Toggle Live Snap Display  popped via GTK */
static gboolean do_live_snap (GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{
    if (liveon) {
	pxd_goUnLive(UNITSMAP);
	liveon = 0;
	g_print("UnLive\n");
	return TRUE;
    }

    liveon = LIVE_SNAP;
    pxd_goSnap(UNITSMAP, 1L);
    g_print("Live Snap\n");

    return TRUE;
}

/* Toggle Live Display	popped via GTK */
static gboolean do_live_pair (GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{
    if (liveon) {
	pxd_goUnLive(UNITSMAP);
	liveon = 0;
	g_print("UnLive\n");
	return TRUE;
    }

    if (pxd_imageZdim() < 2) {
	g_print("Live Pair requires at least 2 frame buffers\n" );
	return TRUE;
    }

    pxd_goLivePair(UNITSMAP, 1L, 2L);
    liveon = LIVE_PAIR;
    g_print("Live Pair\n");
  
    return TRUE;
}


/* Image Complement popped via GTK */
#if USE_PXIPL | USE_PXIPL_THREADS
static gboolean do_pxipl_comp (GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{

    struct pximage  *pximage;

    if (liveon) {
	g_print("This example's complement feature is not intended while in Live mode(s)\n");
	return(TRUE);
    }

    //
    // In most video modes, we are capturing
    // into buffer 1; in live pair, we alternate
    // and request which buffer has the most recent image.
    //
    pxbuffer_t buf = pxd_capturedBuffer(1);
    if (buf == 0)   // nothing ever captured?
	buf = 1;


    /*
     * On some boards, the pxd_defineImage(..., "Default")
     * might be YCrCb. While complementing YCrCb data would work,
     * the result might not be what the viewer expects.
     */
    if (pxd_imageCdim() == 1)
	pximage = pxd_defineImage(1, buf, 0, 0, -1, -1, "Grey");
    else
	pximage = pxd_defineImage(1, buf, 0, 0, -1, -1, "RGB");
    pxip8_pixneg(0, pximage, pximage);

    g_print("PXIPL Complement\n");

    update_window = TRUE;

    return TRUE;
}
#endif

/* Update status bars */
static void update_status()
{
    static  struct timeval otimeval = {0};
    static  guint	 odisplay_count = 0;
    static  pxvbtime_t	 ovbtime = 0;
	    struct timeval ntimeval;
	    pxvbtime_t	 vbtime;
	    gchar *status;

    gettimeofday(&ntimeval, NULL);
    ulong nt = ntimeval.tv_sec*1000L + (ntimeval.tv_usec+1000/2)/1000;
    ulong ot = otimeval.tv_sec*1000L + (otimeval.tv_usec+1000/2)/1000;
    if (nt-ot < 1000)
	return;

    //
    // Display field rate in status bar.
    //
    vbtime = pxd_videoFieldCount(UNITSMAP);
    status = g_strdup_printf ("%f", 1000*(vbtime-ovbtime)/ (double)(nt-ot));
    gtk_label_set_text (GTK_LABEL (field_count_display), status);
    g_free(status);

    //
    // Display number of image buffers in status bar.
    //
    status = g_strdup_printf ("%d", pxd_imageZdim() );
    gtk_label_set_text (GTK_LABEL ( image_buffer_display ), status );
    g_free(status);

    //
    // Display update rate of display area.
    //
    status = g_strdup_printf ("%f", 1000*(display_count-odisplay_count)/(double)(nt-ot) );
    gtk_label_set_text (GTK_LABEL ( display_rate_display ), status );
    g_free(status);

    //
    // What is new becomes old
    //
    odisplay_count = display_count;
    otimeval = ntimeval;
    ovbtime  = vbtime;
}

/* Field capture signalled via XCLIB */
#if UPDATE_SIGNAL
static void video_signalled(int sig)
{
    if (pthread_mutex_trylock(&signal_mutex) == 0) {
	update_imagedisplay(FALSE);
	pthread_mutex_unlock(&signal_mutex);
    }
    //
    // The timer may not have a chance to pop
    // if displaying live video from a high frame
    // rate camera, or if on a slow PC. So ...
    if (1) {
	pxd_mesgFault(UNITSMAP);
	update_status();
    }

    //
    // So as to implemement repeated snap mode.
    // Note that for interlace video, this function
    // is signalled twice per frame; the pxd_goSnap()
    // will simply fail if we haven't yet captured
    // the second field.
    //
    if (liveon == LIVE_SNAP)
	pxd_goSnap(UNITSMAP, 1L);
}
#endif

/* Timer popped via GTK */
static gboolean timer_popped(gpointer user_data)
{

    #if UPDATE_TIMER
	if (update_window) {
	    update_imagedisplay(TRUE);
	    update_window = FALSE;
	} else {
	    update_imagedisplay(FALSE);
	}
	if (liveon == LIVE_SNAP)
	    pxd_goSnap(UNITSMAP, 1L);
	update_status();
    #endif
    #if UPDATE_SIGNAL
	pthread_mutex_lock(&signal_mutex);
	// A signal handles normal image display updates.
	if (update_window) {
	    update_imagedisplay(TRUE);
	    update_window = FALSE;
	}
	update_status();
	pthread_mutex_unlock(&signal_mutex);
    #endif
    pxd_mesgFault(UNITSMAP);
    return TRUE;
}

/* Change Contrast popped via GTK */
static void change_contrast (GtkAdjustment *adjust, gpointer user_data)
{
    setGain(adjust->value);
}

/* Change Brightness popped via GTK  */
static void change_brightness (GtkAdjustment *adjust, gpointer user_data)
{
    setBright(adjust->value);
}

/* Redraw window popped via GTK */
static int expose_event( GtkWidget *widget, GdkEventExpose *event )
{
    update_window = TRUE;
    return FALSE;
}

/* Close window popped via GTK */
static void close_window ( GtkWidget * window, gpointer data )
{
    pxd_goUnLive(UNITSMAP);
    g_print("Close Window\n");
    gtk_main_quit ();
}



/* MAIN. Open PIXCI, setup GTK */
int main (int argc, char *argv[])
{
    //
    // If dislaying from multiple threads on a
    // single X11 'Display', X11 requires ...
    //
    #if USE_PXIPL_THREADS
	XInitThreads();
    #endif

    //
    // Setup and initialize GTK window library.
    //
    GtkWidget *main_window, *vert_box, *control_table;
    GtkWidget *snap_button, *live_button, *live_snap_button, *pxipl_button, *swap_pair_button, *live_pair_button;
    GtkWidget *field_count_label, *image_buffer_label, *display_rate_label;
    //
    // Contrast and Brightness controls for PIXCI SV2/3/4/5/6/7/8
    GtkWidget *contrast_slider, *brightness_slider;
    GtkWidget *contrast_label, *brightness_label;
    GtkObject *contrast_adjust, *brightness_adjust;

    gtk_init (&argc, &argv);

    //
    // Catch signals.
    //
    signal(SIGINT, signaled);
    signal(SIGFPE, signaled);

    //
    // Open and set video format.
    //
    if (do_open() < 0)
	return(1);

    //
    // Setup display area size.
    //
    // We need to leave some space for controls
    //
    #define MAX_DISPLAY_AREA_PERC 80	    // a percentage
    //
    #if USE_PXIPL | USE_PXIPL_THREADS
    {
	double	scalex, scaley, aspect;
	// If using PXIPL for display: aspect ratio can
	// be corrected and the image resize.
	display_wind.nw.x = 0;
	display_wind.nw.y = 0;
	display_wind.se.x = (int)gdk_screen_get_width (gdk_screen_get_default())*(MAX_DISPLAY_AREA_PERC/100.);
	display_wind.se.y = (int)gdk_screen_get_height(gdk_screen_get_default())*(MAX_DISPLAY_AREA_PERC/100.);
	if (!PXIPL_MAXDISPLAY)
	    display_wind.se.x = MIN(display_wind.se.x, pxd_imageXdim());

	aspect = pxd_imageAspectRatio();
	if (aspect == 0.0)
	    aspect = 1.0;
	scalex = display_wind.se.x/(double)pxd_imageXdim();
	scaley = display_wind.se.y/((double)pxd_imageYdim()*aspect);
	scalex = MIN(scalex, scaley);
	display_wind.se.x = (int)(pxd_imageXdim() * scalex);
	display_wind.se.y = (int)(pxd_imageYdim() * scalex * aspect);

	// Force display width & height, limited only by
	// max screen width & height, and not corrected for
	// aspect ratio.
	if (PXIPL_DISPLAY_WIDTH)
	    display_wind.se.x = MIN(PXIPL_DISPLAY_WIDTH, gdk_screen_get_width(gdk_screen_get_default()));
	if (PXIPL_DISPLAY_HEIGHT)
	    display_wind.se.y = MIN(PXIPL_DISPLAY_HEIGHT, gdk_screen_get_height(gdk_screen_get_default()));

	display_width  = display_wind.se.x;
	display_height = display_wind.se.y;
    }
    #elif USE_X11
	// If using X11 for display: The captured image isn't resized,
	// nor aspect ratio corrected. Use same dimensions as captured
	// image, but not larger than the desktop.
	//
	display_width  = MIN( pxd_imageXdim(), (gint)gdk_screen_get_width (gdk_screen_get_default ())*(MAX_DISPLAY_AREA_PERC/100.));
	display_height = MIN( pxd_imageYdim(), (gint)gdk_screen_get_height(gdk_screen_get_default ())*(MAX_DISPLAY_AREA_PERC/100.));
	// Allocate a local image buffer for display: always RGB+pad
	rgbbufsize = (display_width * 4) * display_height;
	if (!(rgbbuf = malloc(rgbbufsize))) {
	    do_close();
	    return(1);
	}
    #elif USE_GDK
	// If using GTK for display: The captured image isn't resized,
	// nor aspect ratio corrected. Use same dimensions as captured
	// image, but not larger than the desktop.
	display_width  = MIN( pxd_imageXdim(), (gint)gdk_screen_get_width (gdk_screen_get_default ())*(MAX_DISPLAY_AREA_PERC/100.));
	display_height = MIN( pxd_imageYdim(), (gint)gdk_screen_get_height(gdk_screen_get_default ())*(MAX_DISPLAY_AREA_PERC/100.));
	// Allocate a local image buffer for display.
	rgbbufsize = display_width * display_height * (pxd_imageCdim()==1? 1: 3);
	if (!(rgbbuf = malloc(rgbbufsize))) {
	    do_close();
	    return(1);
	}

    #endif
    g_print( "Display  Width: %d\n", display_width   );
    g_print( "Display Height: %d\n", display_height  );
    g_print( "PIXCI(R) X Dim: %d\n", pxd_imageXdim() );
    g_print( "PIXCI(R) Y Dim: %d\n", pxd_imageYdim() );

    //
    // Define GTK windows and controls.
    //
    main_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (main_window), "EPIX(R) PIXCI(R) GTK 2.0 Example" );
    vert_box	  = gtk_vbox_new ( FALSE, 0);
    display_area  = gtk_drawing_area_new();
    gtk_widget_set_size_request (display_area, display_width, display_height);
    control_table = gtk_table_new (10, 10, FALSE);
    snap_button   = gtk_button_new_with_label ("Snap");
    live_button   = gtk_button_new_with_label ("Live");
    live_snap_button = gtk_button_new_with_label ("Live Snap");
    #if USE_PXIPL | USE_PXIPL_THREADS
	pxipl_button = gtk_button_new_with_label ("PXIPL Complement");
    #endif
  //swap_pair_button = gtk_button_new_with_label ("Swap Pair");
    live_pair_button = gtk_button_new_with_label ("Live Pair");
    // Contrast and Brightness controls for PIXCI SV2/3/4/5/6/7/8 & A110/A310
    if (PIXCI_is_SV2345678 || PIXCI_is_AX10) {
	contrast_adjust   = GTK_OBJECT ( gtk_adjustment_new (getGain(), 0, 100, 1, 10, 0) ); // 100 is max
	brightness_adjust = GTK_OBJECT ( gtk_adjustment_new (getBright(), 0, 100, 1, 10, 0) ); // 100 is max
	contrast_slider   = gtk_hscale_new ( GTK_ADJUSTMENT(contrast_adjust) );
	brightness_slider = gtk_hscale_new ( GTK_ADJUSTMENT(brightness_adjust) );
	gtk_scale_set_digits ( GTK_SCALE ( contrast_slider ), 0 );
	gtk_scale_set_digits ( GTK_SCALE ( brightness_slider ), 0 );
	gtk_scale_set_draw_value ( GTK_SCALE ( contrast_slider ), TRUE );
	gtk_scale_set_draw_value ( GTK_SCALE ( brightness_slider ), TRUE );
	contrast_label	 = gtk_label_new ( "Adjust Contrast:" );
	brightness_label = gtk_label_new ( "Adjust Brightness:" );
	gtk_label_set_justify ( GTK_LABEL (contrast_label), GTK_JUSTIFY_LEFT );
	gtk_label_set_justify ( GTK_LABEL (brightness_label), GTK_JUSTIFY_RIGHT );
    }
    field_count_label	 = gtk_label_new ( "Field Rate:" );
    image_buffer_label	 = gtk_label_new ( "Image Buffers:" );
    display_rate_label	 = gtk_label_new ( "Display Rate:" );
    field_count_display  = gtk_label_new ( "0" );
    image_buffer_display = gtk_label_new ( "0" );
    display_rate_display = gtk_label_new ( "0" );

    //
    // Put display area in box, layout controls in table, put table in box, and place box in main window
    //
    gtk_box_pack_start (GTK_BOX (vert_box), display_area, FALSE, FALSE, 0);
    gtk_table_attach_defaults (GTK_TABLE (control_table), snap_button, 0, 3, 0, 2);
    gtk_table_attach_defaults (GTK_TABLE (control_table), live_snap_button, 0, 3, 2, 4);
    #if USE_PXIPL | USE_PXIPL_THREADS
	gtk_table_attach_defaults (GTK_TABLE (control_table), live_button, 3, 7, 0, 2);
	gtk_table_attach_defaults (GTK_TABLE (control_table), pxipl_button, 3, 7, 2, 4);
    #else
	gtk_table_attach_defaults (GTK_TABLE (control_table), live_button, 3, 7, 0, 4);
    #endif
    gtk_table_attach_defaults (GTK_TABLE (control_table), live_pair_button, 7, 10, 0, 2);
  //gtk_table_attach_defaults (GTK_TABLE (control_table), swap_pair_button, 7, 10, 2, 4);
    if (PIXCI_is_SV2345678 || PIXCI_is_AX10) {
	gtk_table_attach_defaults (GTK_TABLE (control_table), contrast_label, 0, 2, 4, 5);
	gtk_table_attach_defaults (GTK_TABLE (control_table), contrast_slider, 2, 10, 4, 5);
	gtk_table_attach_defaults (GTK_TABLE (control_table), brightness_label, 0, 2, 5, 6);
	gtk_table_attach_defaults (GTK_TABLE (control_table), brightness_slider, 2, 10, 5, 6);
    }
    gtk_table_attach_defaults (GTK_TABLE (control_table), field_count_label, 0, 2, 9, 10);
    gtk_table_attach_defaults (GTK_TABLE (control_table), field_count_display, 2, 4, 9, 10);
    gtk_table_attach_defaults (GTK_TABLE (control_table), image_buffer_label, 4, 6, 9, 10);
    gtk_table_attach_defaults (GTK_TABLE (control_table), image_buffer_display, 6, 7, 9, 10);
    gtk_table_attach_defaults (GTK_TABLE (control_table), display_rate_label, 7, 9, 9, 10);
    gtk_table_attach_defaults (GTK_TABLE (control_table), display_rate_display, 9, 10, 9, 10);
    gtk_box_pack_end (GTK_BOX (vert_box), control_table, FALSE, FALSE, 0);
    gtk_container_add (GTK_CONTAINER (main_window), vert_box);


    //
    // Setup GTK control signals to call functions.
    //
    g_signal_connect (G_OBJECT ( snap_button ),      "clicked",  G_CALLBACK ( do_snap ), NULL);
    g_signal_connect (G_OBJECT ( live_button ),      "clicked",  G_CALLBACK ( do_live ), NULL);
    g_signal_connect (G_OBJECT ( live_snap_button ), "clicked",  G_CALLBACK ( do_live_snap ), NULL);
    #if USE_PXIPL | USE_PXIPL_THREADS
	g_signal_connect (G_OBJECT ( pxipl_button ), "clicked",  G_CALLBACK ( do_pxipl_comp ), NULL);
    #endif
    g_signal_connect (G_OBJECT ( live_pair_button ), "clicked",  G_CALLBACK ( do_live_pair ), NULL);
  //g_signal_connect (G_OBJECT ( swap_pair_button ), "clicked",  G_CALLBACK ( do_swap_pair ), NULL);
    if (PIXCI_is_SV2345678 || PIXCI_is_AX10) {
	g_signal_connect (G_OBJECT ( contrast_adjust ), "value_changed",   G_CALLBACK ( change_contrast ), NULL);
	g_signal_connect (G_OBJECT ( brightness_adjust ), "value_changed", G_CALLBACK ( change_brightness ), NULL);
    }
    g_signal_connect (G_OBJECT ( display_area ), "expose_event", G_CALLBACK ( expose_event ), NULL);
    g_signal_connect (G_OBJECT ( main_window ),  "destroy",	 G_CALLBACK ( close_window ), NULL);


    //
    // Display GTK windows
    //
    gtk_widget_show_all (main_window);

    //
    // Setup timer or signal to detect a new image to be displayed.
    //
    #if UPDATE_TIMER
	g_print("timeout added\n");
	g_timeout_add(5, timer_popped, NULL);
    #endif
    #if UPDATE_SIGNAL
        signal(SIGUSR1, video_signalled);
	if (pxd_eventCapturedFieldCreate(UNITSMAP, SIGUSR1, NULL) < 0) {
	    g_print("Can't set signal upon captured field\n");
	    do_close();
	    return(1);
	}
	// the timer is only used to update display & video statistics.
	g_timeout_add(1000, timer_popped, NULL);
    #endif


    //
    // Run GTK Program
    //
    gtk_main();

    //
    // All done w. PIXCI
    //
    do_close();

    #if USE_PXIPL
    #elif USE_PXIPL_THREADS
	if (x11state != NULL)
	    pxio9_X11Display2Done(NULL, &x11state);
    #elif USE_X11
	if (x11Ximage) {
	    XDestroyImage(x11Ximage);	// also free's
	    rgbbuf = NULL;		// rgbbuf
	}
	if (rgbbuf)
	    free(rgbbuf);
    #elif USE_GDK
	if (rgbbuf)
	    free(rgbbuf);
    #endif

    return 0;
}

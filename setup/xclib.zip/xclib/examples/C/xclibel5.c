/*
 *
 *	xclibel5.c	External	25-Feb-2020
 *
 *	Copyright (C)  2002-2018  EPIX, Inc.  All rights reserved.
 *
 *	Example program for XCLIB C Library, SCF Level functions.
 *	Example assumes Linux 'terminal' environment.
 *
 *	Demonstrates XCLIB and/or PXIPL functions for capture and
 *	display from multiple PIXCI(R) frame grabbers where
 *	the boards are not identical or each board is operating
 *	at a different resolution or a different camera.
 *
 */


/*
 *  INSTRUCTIONS:
 *
 *
 *  1.1) Choose whether we are operating the identical boards
 *  but with different resolutions and/or cameras.
 *  Or whether we are operating different  boards.
 *  The former can be done with one open instance of the library.
 *  and allows performing some actions on all boards with one function call.
 *  The latter requires opening multiple instances of the library,
 *  one for each different type of board.
 *
 *  Only one of these choices should have value 1, the others should be 0.
 *
 *  Currently, only PXELIB_ENHANCED is supported.
 */
#if !defined(ONELIB_TWOUNIT) && !defined(TWOLIB_ONEUNIT) && !defined(PXDLIB_ENHANCED) && !defined(PXELIB_ENHANCED)
    #define ONELIB_TWOUNIT	0   // open one instance which controls multiple, identical, boards ..
				    // .. using structured functions
    #define TWOLIB_ONEUNIT	0   // open multiple instances, each controlling one board, identical or not, ..
				    // .. using structured functions
    #define PXDLIB_ENHANCED	0   // open one instance which controls multiple, identical, boards ..
				    // .. using new enhanced features of pxd_ functions
				    // .. Only FORMATFILE_LOAD option, below, is suppported
    #define PXELIB_ENHANCED	1   // open multiple instances, each controlling one board, identical or not, ..
				    // .. using new pxe_ functions, which are enhanced variations of pxd_ functions
#endif

/*
 *
 *  1.2)  Set 'define' options below according to the intended camera
 *	and video format(s).
 *
 *	For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV6L, and SV6 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, or PAL/YC.
 *	(The SV5A and SV5B do not support NTSC/YC or PAL/YC).
 *	For PIXCI(R) SV7 frame grabbers
 *	common choices are RS-170, NSTC, CCIR, or PAL.
 *	For PIXCI(R) SV8 frame grabbers
 *	common choices are RS-170, NSTC, NTSC/YC, CCIR, PAL, PAL/YC.
 *
 *	For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32, D2X, D3X, D3XE,
 *	E1, E1DB, E4, E4DB, E4G2, E4TX2, E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-POCL,
 *	EB1mini, miniH2b, miniH2, EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB, ELS2, SI, SI1, SI2, and SI4
 *	frame grabbers, use "default" to select the default format for
 *	the camera for which the PIXCI(R) frame grabber is intended.
 *	For non default formats, use XCAP to save the video setup to
 *	a file, and set FORMATFILE_LOAD to the saved file's path name.
 *	For camera's with RS-232 control, note that the saved
 *	video setup only resets the PIXCI(R) frame grabber's
 *	settings, but XCLIB does not reset the camera's settings.
 *	For selected Camera Link cameras w. serial controls,
 *	the video setup file may include serial commands which are
 *	automatically sent by XCLIB to the camera.
 *
 *	Alternately, this could be modified to use getenv("PIXCI"),
 *	GetPrivateProfileString(...), RegQueryValueEx(...), or any
 *	other convention chosen by the programmer to allow run time
 *	selection of the video format and resolution.
 *
 */

#if !defined(FORMAT_UNIT0) && !defined(FORMAT_UNIT1) \
 && !defined(FORMATFILE_LOAD) && !defined(FORMATFILE_COMP)
					// For PIXCI(R) SV2, SV3, SV4, SV5, SV5A, SV5B, SV5L, SV6
    //#define FORMAT_UNIT0  "RS-170"	// RS-170 on input 2
    //#define FORMAT_UNIT0  "NTSC"	// NTSC on input 2
    //#define FORMAT_UNIT0  "NTSC/YC"	// NSTC S-Video on input 1		(N/A on SV5A,SV5B)
    //#define FORMAT_UNIT0  "CCIR"	// CCIR on input 2
    //#define FORMAT_UNIT0  "PAL"	// PAL (B,D,G,H,I) on input 2
    //#define FORMAT_UNIT0  "PAL/YC"	// PAL (B,D,G,H,I) S-Video on input 1	(N/A on SV5A,SV5B)
    //#define FORMAT_UNIT1  "RS-170"	// RS-170 on input 2
    //#define FORMAT_UNIT1  "NTSC"	// NTSC on input 2
    //#define FORMAT_UNIT1  "NTSC/YC"	// NSTC S-Video on input 1		(N/A on SV5A,SV5B)
    //#define FORMAT_UNIT1  "CCIR"	// CCIR on input 2
    //#define FORMAT_UNIT1  "PAL"	// PAL (B,D,G,H,I) on input 2
    //#define FORMAT_UNIT1  "PAL/YC"	// PAL (B,D,G,H,I) S-Video on input 1	(N/A on SV5A,SV5B)

					// For PIXCI(R) SV7
    //#define FORMAT_UNIT0   "RS-170"	// RS-170
    //#define FORMAT_UNIT0   "NTSC"	// NTSC
    //#define FORMAT_UNIT0   "CCIR"	// CCIR
    //#define FORMAT_UNIT0   "PAL"	// PAL
    //#define FORMAT_UNIT1   "RS-170"	// RS-170
    //#define FORMAT_UNIT1   "NTSC"	// NTSC
    //#define FORMAT_UNIT1   "CCIR"	// CCIR
    //#define FORMAT_UNIT1   "PAL"	// PAL

					// For PIXCI(R) SV8
    //#define FORMAT_UNIT0   "RS-170"	// RS-170 on BNC 0
    //#define FORMAT_UNIT0   "NTSC"	// NTSC on BNC 0
    //#define FORMAT_UNIT0   "NTSC/YC"	// NSTC S-Video
    //#define FORMAT_UNIT0   "CCIR"	// CCIR on BNC 0
    //#define FORMAT_UNIT0   "PAL"	// PAL on BNC 0
    //#define FORMAT_UNIT0   "PAL/YC"	// PAL (B,D,G,H,I) S-Video
    //#define FORMAT_UNIT1   "RS-170"	// RS-170 on BNC 0
    //#define FORMAT_UNIT1   "NTSC"	// NTSC on BNC 0
    //#define FORMAT_UNIT1   "NTSC/YC"	// NSTC S-Video
    //#define FORMAT_UNIT1   "CCIR"	// CCIR on BNC 0
    //#define FORMAT_UNIT1   "PAL"	// PAL on BNC 0
    //#define FORMAT_UNIT1   "PAL/YC"	// PAL (B,D,G,H,I) S-Video


					// For PIXCI(R) A, CL1, CL2, CL3SD, D, D24, D32,
					// D2X, D3X, D3XE, E1, E1DB, E4, E4DB, E4G2, E4TX2,
					// E8, E8CAM, E8DB, e104x4, EB1, EB1G2, EB1-POCL, EB1G2-PoCL, EB1mini, miniH2b, miniH2,
					// EC1, ECB1, ECB1-34, ECB2, EL1, EL1DB,
					// ELS2, SI, SI1, SI2, SI4
      #define FORMAT_UNIT0  "default"	// as per board's intended camera
      #define FORMAT_UNIT1  "default"	// as per board's intended camera

						// For any PIXCI(R) frame grabber
						// using a format file saved by XCAP ..
  //#define FORMATFILE_LOAD   "xcvidset.fmt"	// .. loaded from file during execution
						// for FORMATFILE_LOAD and ONELIB_TWOUNIT
  //#define FORMATFILE_LOAD0	"xcvidset0.fmt" // .. loaded from file during execution
  //#define FORMATFILE_LOAD1	"xcvidset1.fmt" // loaded from file during execution
						// for TWOLIB_ONEUNIT
#endif
#if PXDLIB_ENHANCED
    #if !defined(FORMATFILE_LOAD)
	#error The PXDLIB_ENHANCED option requires FORMATFILE_LOAD.
    #endif
#endif
#if PXELIB_ENHANCED
#endif
#if TWOLIB_ONEUNIT
    #if defined(FORMATFILE_LOAD)
	#error The TWOLIB_ONEUNIT option does not use FORMATFILE_LOAD.
    #endif
#endif
#if ONELIB_TWOUNIT
    #if defined(FORMATFILE_LOAD0) || defined(FORMATFILE_LOAD1)
	#error The ONELIB_TWOUNIT option does not use FORMATFILE_LOAD0 or FORMATFILE_LOAD1.
    #endif
#endif


/*
 *  2.1) Number of expected PIXCI(R) frame grabbers.
 *  Currently, this example's code only supports 1 or 2;
 *  although there are partial 'hooks' to support more.
 *
 *  For PIXCI(R) frame grabbers with multiple, functional units,
 *  the XCLIB presents the two halves of the PIXCI(R) E1DB, E4DB, E4G2-2F, E4TX2-2F,
 *  E8CAM, E8DB, e104x4-2f, ECB2, EL1DB, ELS2, miniH2b, SI2, or SV7 frame grabbers,
 *  or the three parts of the PIXCI(R) E4G2-F2B, E4TX2-F2B, e104x4-f2b frame grabber,
 *  or the four quarters of the PIXCI(R) E4G2-4B, E4TX2-4B, e104x4-4b or SI4 frame grabbers,
 *  as two, three, or four independent PIXCI(R) frame grabbers, respectively.
 *
 */
#if !defined(UNITS)
    #define UNITS	2
#endif
#if !defined(UNITSMAP)
    #define UNITSMAP	((1<<UNITS)-1)	/* shorthand - bitmap of all units */
#endif



/*
 *  2.3) Optionally, set driver configuration parameters.
 *  These are normally left to the default, "".
 *  The actual driver configuration parameters include the
 *  desired PIXCI(R) frame grabbers, but to make configuation easier,
 *  code, below, will automatically add board selection to this.
 */
#if !defined(DRIVERPARMS)
    //#define DRIVERPARMS "-QU 0"   // don't use interrupts
      #define DRIVERPARMS ""	    // default
#endif

/*
 *  4) Select directory for saving of images.
 *  This example will not overwrite existing images files;
 *  so directory selection is not critical.
 */
#if !defined(IMAGEFILE_DIR)
    #define IMAGEFILE_DIR    "."
#endif




/*
 *  5a) Compile with GCC w/out PXIPL for 32 bit Linux on Intel i386 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/xclib_i386.a -lm
 *
 *	Compile with GCC with PXIPL for 32 bit Linux on Intel i386 as:
 *
 *	    gcc -DC_GNU32=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/pxipl_i386.a ../../lib/xclib_i386.a -lm
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on Intel x86_64 as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/xclib_x86_64.a -lm
 *
 *	Compile with GCC with PXIPL for 64 bit Linux on Intel x86_64  as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/pxipl_x86_64.a ../../lib/xclib_x86_64.a -lm
 *
 *	Compile with GCC w/out PXIPL for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/xclib_aarch64.a -lm
 *
 *	Compile with GCC with PXIPL for 64 bit Linux on nVidia/ARM TX1/TX2/Xavier as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/pxipl_aarch64.a ../../lib/xclib_aarch64.a -lm
 *
 *	Compile with GCC w/out PXIPL for 32 bit Linux on nVidia/ARM TK1
 *	or Boundary Devices/ARM NITROGEN6 as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/xclib_armv7l.a -lm
 *
 *	Compile with GCC with PXIPL for 32 bit Linux on nVidia/ARM TK1
 *	or Boundary Devices/ARM NITROGEN6 as:
 *
 *	    gcc -DC_GNU64=400 -DOS_LINUX -I../../inc -no-pie xxclibel5.c ../../lib/pxipl_armv7l.a ../../lib/xclib_armv7l.a -lm
 *
 *	Run as:
 *	    ./a.out
 *
 */


/*
 *  NECESSARY INCLUDES:
 */
#include <stdio.h>		// c library
#include <signal.h>		// c library
#include <stdlib.h>		// c library
#include <stdarg.h>		// c library
#include <unistd.h>		// c library
#include <limits.h>		// c library
#include <string.h>		// c library
#include <sys/time.h>		// c library
#include "xcliball.h"		// function prototypes
#if USE_PXIPL
  #include "pxipl.h"		// function prototypes
#endif


/*
 *  SUPPORT STUFF:
 *
 *  Slow down execution speed so
 *  each step/function can be observed.
 */
static void user(const char *mesg)
{
    if (mesg && *mesg)
	printf("%s\n", mesg);
    fprintf(stderr, "\n\nContinue (Key ENTER) ?");
    while (getchar() != '\n') ;
    fprintf(stderr, "\n");
}

/*
 * Video 'interrupt' callback function.
 */
static int fieldirqcount0 = 0;
static int fieldirqcount1 = 0;
static void videoirqfunc0(int sig)
{
    fieldirqcount0++;
}
static void videoirqfunc1(int sig)
{
    fieldirqcount1++;
}

static	pxdstate_s *pxdstates[UNITS];


/*
 * Open the XCLIB C Library for use.
 */
static int do_open(void)
{
    int err, u;


    #if PXELIB_ENHANCED
	for (u = 0; u < UNITS; u++) {
	    char driverparms[80];
	    char *formatname = "";
	    char *formatfile = "";
	    #if defined(FORMATFILE_LOAD)
		formatfile = FORMATFILE_LOAD;
	    #endif
	    #if defined(FORMATFILE_LOAD0)
		if (u == 0)
		    formatfile = FORMATFILE_LOAD0;
	    #endif
	    #if defined(FORMATFILE_LOAD1)
		if (u == 1)
		    formatfile = FORMATFILE_LOAD1;
	    #endif
	    #if defined(FORMAT_UNIT0)
		if (u == 0)
		    formatname = FORMAT_UNIT0;
	    #endif
	    #if defined(FORMAT_UNIT1)
		if (u == 1)
		    formatname = FORMAT_UNIT1;
	    #endif
	    driverparms[sizeof(driverparms)-1] = 0; // this & snprintf: overly conservative - avoids warning messages
	    snprintf(driverparms, sizeof(driverparms)-1, "-DM 0x%x %s", 1<<u, DRIVERPARMS);
	    printf("Opening EPIX(R) PIXCI(R) Frame Grabber unit %d,\n", u);
	    printf("using configuration parameters '%s',\n", DRIVERPARMS? DRIVERPARMS: "default");
	    printf("using predefined format '%s',\n", formatname);
	    printf("using format file '%s',\n", formatfile);
	    pxdstates[u] = pxe_XCLIBinstantiate();
	    if ((err=pxe_PIXCIopen(pxdstates[u], driverparms, formatname, formatfile)) < 0) {
		printf("Open Error %s(%d)\a\a\n", pxd_mesgErrorCode(err), err);
		pxe_mesgFault(pxdstates[u], 1);
		user("");
		return(err);
	    }
	}
    #endif

    user("Open OK");
    //
    // For the sake of demonstrating optional interrupt hooks.
    //
    signal(SIGUSR1, videoirqfunc0);
    signal(SIGUSR2, videoirqfunc1);
    for (u = 0; u < UNITS; u++) {
	if (pxe_eventCapturedFieldCreate(pxdstates[u], 1, u==0?SIGUSR1:SIGUSR2, NULL) >= 0)
	    printf("Unit %d: Hooked signal upon captured field\n", u);
	else
	    printf("Unit %d: Couldn't hook signal upon captured field\n", u);
	user("");
    }
    //
    return(err);
}

/*
 * Report image frame buffer memory size
 */
static void do_imsize(int u)
{
    printf("Unit %d: Image frame buffer memory size: %.3f Kbytes\n", u, (double)pxe_infoMemsize(pxdstates[u], 1)/1024);
    printf("Unit %d: Image frame buffers           : %d\n", u, pxe_imageZdim(pxdstates[u]));
    printf("Unit %d: Number of boards              : %d\n", u, pxe_infoUnits(pxdstates[u]));

    user("");
}

/*
 * Report image resolution.
 */
static void do_vidsize(int u)
{
    printf("Image resolution:\n");
    printf("Unit %d: xdim           = %d\n", u, pxe_imageXdim(pxdstates[u]));
    printf("Unit %d: ydim           = %d\n", u, pxe_imageYdim(pxdstates[u]));
    printf("Unit %d: colors         = %d\n", u, pxe_imageCdim(pxdstates[u]));
    printf("Unit %d: bits per pixel = %d\n", u, pxe_imageCdim(pxdstates[u])*pxe_imageBdim(pxdstates[u]));

    user("");
}



/*
 * Capture
 */
static void do_video1(int u)
{
    int err;


    //
    // Capture image into buffer 1.
    //
    printf("Unit %d: Field count before snap=%ld\n", u, (long)pxe_videoFieldCount(pxdstates[u], 1));
    err = pxe_doSnap(pxdstates[u], 1, 1, 0);
    printf("Unit %d: pxe_doSnap: %s\n", u, err>=0? "Ok": pxd_mesgErrorCode(err));
    printf("Unit %d: Field count after snap=%ld\n", u, (long)pxe_videoFieldCount(pxdstates[u], 1));
    printf("Unit %d: Captured field count from IRQ hook=%d\n", u, u==0? fieldirqcount0: fieldirqcount1);
    //
    // Check for faults, such as erratic sync
    // or insufficient PCI bus bandwidth
    //
    pxe_mesgFault(pxdstates[u], 1);
    printf("Unit %d: Image snapped into buffer 1\n", u);
    user("");

}

/*
 * General purpose output will pulse, running for several seconds.
 */
static void do_extout1(int u)
{
    pxe_getGPOut(pxdstates[u], 1, 0);
    printf("Unit %d: Ready to watch general purpose output signal?\n", u);
    user("");
}
static void do_extout2(int u)
{
    int     j;

    printf("Toggling general purpose output ..\n");
    for (j = 60*3; j--; ) {
	pxe_getGPOut(pxdstates[u], 1, 0x1);
	pxe_getGPOut(pxdstates[u], 1, 0x0);
    }
    printf("Unit %d: general purpose output pulses done\n", u);
    user("");
}

/*
 * The general purpose input is often used as a flag to start an
 * activity, with the application code looping until
 * the general purpose input changes.
 * No signal may be present during this demo, so as to avoid
 * indefinite loops the count is simply printed twice,
 * giving the user an opportunity to toggle the input.
 * This (silently) sets the GPOut, to provide a convenient
 * signal source for testing.
 */
static void do_extin1(int u)
{
    int err = 0;
    //
    // On PIXCI(R) D, D24, D32 frame grabbers the input, if available,
    // is latched, until explicitly reset.
    // This has no effect on other PIXCI(R) frame grabbers
    // in which the inputs are level sensitive.
    //
    err = pxe_setGPIn(pxdstates[u], 1, 0x0);
    if (err < 0)
	printf("Unit %d: pxe_setGPIn: %s\n", u, pxd_mesgErrorCode(err));
    err = pxe_setGPOut(pxdstates[u], 1, 0x0);
    if (err < 0)
	printf("Unit %d: pxe_setGPOut: %s\n", u, pxd_mesgErrorCode(err));
    printf("Unit %d: Current value of general purpose input: 0x%x\n", u, pxe_getGPIn(pxdstates[u], 1, 0));

    user("");
}
static void do_extin2(int u)
{
    int err = 0;

    err = pxe_setGPIn(pxdstates[u], 1, 0x0);
    if (err < 0)
	printf("Unit %d: pxe_setGPIn: %s\n", u, pxd_mesgErrorCode(err));
    err = pxe_setGPOut(pxdstates[u], 1, 0x1);
    if (err < 0)
	printf("Unit %d: pxe_setGPOut: %s\n", u, pxd_mesgErrorCode(err));
    printf("Unit %d: Current value of general purpose input: 0x%x\n", u, pxe_getGPIn(pxdstates[u], 1, 0));

    user("");
}


/*
 * Pixels are transferred to a PC buffer, and numerically displayed.
 */
#define AOI_XDIM    3
#define AOI_YDIM    10
#define COLORS	    3
static uchar   colorimage_buf[AOI_XDIM*AOI_YDIM*COLORS];

static void color_display1(int u)
{
    int     i;
    int     cx = (pxe_imageXdim(pxdstates[u])-AOI_XDIM)/2;  // left coordinate of centered AOI
    int     cy = (pxe_imageYdim(pxdstates[u])-AOI_YDIM)/2;  // top  coordinate of centered AOI
    //
    // Transfer the color data from a selected AOI of
    // the image buffer into the PC buffer in
    // YCrCb (Intensity, Red Chroma and Blue Chroma)
    // format.	The number of bytes to be transfered
    // is 3 times the number of pixels.
    //
    if ((i = pxe_readuchar(pxdstates[u], 1, 1, cx, cy, cx+AOI_XDIM, cy+AOI_YDIM, colorimage_buf, sizeof(colorimage_buf)/sizeof(uchar), "YCRCB")) != AOI_XDIM*AOI_YDIM*3) {
	if (i < 0)
	    printf("Unit %d: pxe_readuchar: %s\n", u, pxd_mesgErrorCode(i));
	else
	    printf("Unit %d: pxe_readuchar error: %d != %d\n", u, i, AOI_XDIM*AOI_YDIM*3);
	user("");
	return;
    }
    printf("Unit %d: Image area of interest transfered for YCrCb\n", u);
    user("");
}
static void color_display2(int u)
{
    int     x, y;
    //
    // Display data from the PC buffer.
    //
    for (y = 0; y < AOI_YDIM; y++) {
	for (x = 0; x < AOI_XDIM; x++) {
	    printf(" Y=%3d  ", colorimage_buf[(y*AOI_XDIM+x)*3+0]);
	    printf("Cr=%3d  ", colorimage_buf[(y*AOI_XDIM+x)*3+1]);
	    printf("Cb=%3d  ", colorimage_buf[(y*AOI_XDIM+x)*3+2]);
	}
	printf("\n");
    }
    user("");
}
static void color_display3(int u)
{
    int     i;
    int     cx = (pxe_imageXdim(pxdstates[u])-AOI_XDIM)/2;  // left coordinate of centered AOI
    int     cy = (pxe_imageYdim(pxdstates[u])-AOI_YDIM)/2;  // top  coordinate of centered AOI
    //
    // Transfer the color data from a selected AOI
    // in the image buffer into the PC buffer in
    // RGB format.
    //
    if ((i = pxe_readuchar(pxdstates[u], 1, 1, cx, cy, cx+AOI_XDIM, cy+AOI_YDIM, colorimage_buf, sizeof(colorimage_buf)/sizeof(uchar), "RGB")) != AOI_XDIM*AOI_YDIM*3) {
	if (i < 0)
	    printf("Unit %d: pxe_readuchar: %s\n", u, pxd_mesgErrorCode(i));
	else
	    printf("Unit %d: pxe_readuchar error: %d != %d\n", u, i, AOI_XDIM*AOI_YDIM);
	user("");
	return;
    }
    printf("Unit %d: Image area of interest transfered for RGB\n", u);
    user("");
}
static void color_display4(int u)
{
    int     x, y;
    //
    // Display data from the PC buffer.
    //
    for (y = 0; y < AOI_YDIM; y++) {
	for (x = 0; x < AOI_XDIM; x++) {
	    printf("R=%3d ", colorimage_buf[(y*AOI_XDIM+x)*3+0]);
	    printf("G=%3d ", colorimage_buf[(y*AOI_XDIM+x)*3+1]);
	    printf("B=%3d ", colorimage_buf[(y*AOI_XDIM+x)*3+2]);
	}
	printf("\n");
    }
    user("");
}
static void color_display5(int u)
{
    int     i;
    int     cx = (pxe_imageXdim(pxdstates[u])-AOI_XDIM)/2;  // left coordinate of centered AOI
    int     cy = (pxe_imageYdim(pxdstates[u])-AOI_YDIM)/2;  // top  coordinate of centered AOI
    //
    // Transfer the color data from a selected AOI
    // in the the image buffer into the PC buffer in
    // BSH format.
    //
    if ((i = pxe_readuchar(pxdstates[u], 1, 1, cx, cy, cx+AOI_XDIM, cy+AOI_YDIM, colorimage_buf, sizeof(colorimage_buf)/sizeof(uchar), "BSH")) != AOI_XDIM*AOI_YDIM*3) {
	if (i < 0)
	    printf("Unit %d: pxe_readuchar: %s\n", u, pxd_mesgErrorCode(i));
	else
	    printf("Unit %d: pxe_readuchar error: %d != %d\n", u, i, AOI_XDIM*AOI_YDIM*3);
	user("");
	return;
    }
    printf("Unit %d: Image area of interest transfered for BSH\n", u);
    user("");
}
static void color_display6(int u)
{
    int     x, y;
    //
    // Display data from the the PC buffer.
    // The HSB values, ranging from 0 to 255, are rescaled
    // as displayed into the more typical 0 to 1 for S and B,
    // and 0 to 360 for H.
    //
    for (y = 0; y < AOI_YDIM; y++) {
	for (x = 0; x < AOI_XDIM; x++) {
	    printf("B=%5.2f ", colorimage_buf[(y*AOI_XDIM+x)*3+0]/255.);
	    printf("S=%5.2f ", colorimage_buf[(y*AOI_XDIM+x)*3+1]/255.);
	    printf("H=%3.0f ", colorimage_buf[(y*AOI_XDIM+x)*3+2]*360./256.);
	}
	printf("\n");
    }
    user("");
}
#undef	AOI_XDIM
#undef	AOI_YDIM
#undef	COLORS



/*
 * Pixels are transferred to a PC buffer, and numerically displayed.
 */
#define AOI_XDIM    9
#define AOI_YDIM    10
static uchar   monoimage_buf8[AOI_XDIM*AOI_YDIM];
static ushort  monoimage_buf16[AOI_XDIM*AOI_YDIM];

static void bw_display1(int u)
{
    int     i;
    int     cx = (pxe_imageXdim(pxdstates[u])-AOI_XDIM)/2;  // left coordinate of centered AOI
    int     cy = (pxe_imageYdim(pxdstates[u])-AOI_YDIM)/2;  // top  coordinate of centered AOI
    //
    // Transfer the monochrome data from a selected AOI of
    // the image buffer into the PC buffer, as 8 bit pixels.
    // Or,
    // Transfer the monochrome data from a selected AOI of
    // the image buffer into the PC buffer, as 8 to 16 bit pixels.
    //
    // The ushort array could be used for both for 8 bit pixels, but
    // users of 8 bit pixels commonly assume pixel<=>byte,
    // and is more efficient.
    //
    if (pxe_imageBdim(pxdstates[u]) <= 8) {
	if ((i = pxe_readuchar(pxdstates[u], 1, 1, cx, cy, cx+AOI_XDIM, cy+AOI_YDIM, monoimage_buf8, sizeof(monoimage_buf8)/sizeof(uchar), "Grey")) != AOI_XDIM*AOI_YDIM) {
	    if (i < 0)
		printf("Unit %d: pxe_readuchar: %s\n", u, pxd_mesgErrorCode(i));
	    else
		printf("Unit %d: pxe_readuchar error: %d != %d\n", u, i, AOI_XDIM*AOI_YDIM);
	    user("");
	    return;
	}
    } else {
	if (i = pxe_readushort(pxdstates[u], 1, 1, cx, cy, cx+AOI_XDIM, cy+AOI_YDIM, monoimage_buf16, sizeof(monoimage_buf16)/sizeof(ushort), "Grey") != AOI_XDIM*AOI_YDIM) {
	    if (i < 0)
		printf("Unit %d: pxe_readushort: %s\n", u, pxd_mesgErrorCode(i));
	    else
		printf("Unit %d: pxe_readushort error: %d != %d\n", u, i, AOI_XDIM*AOI_YDIM);
	    user("");
	    return;
	}
    }
    printf("Unit %d: Image area of interest transfered\n", u);
    user("");
}
static void bw_display2(int u)
{
    int     x, y;
    //
    // Display data from the PC buffer.
    //
    for (y = 0; y < AOI_YDIM; y++) {
	printf("I = ");
	for (x = 0; x < AOI_XDIM; x++)
	    if (pxe_imageBdim(pxdstates[u]) <= 8)
		printf("%4d ", monoimage_buf8[y*AOI_XDIM+x]);
	    else
		printf("%4d ", monoimage_buf16[y*AOI_XDIM+x]);
	printf("\n");
    }
    user("");
}


/*
 * Be nice and careful: For sake of this example which uses a
 * file name not selected by the user, and which might already exist,
 * don't overwrite the file if it already exists.
 * This check for a pre-existant file is the only reason
 * that fopen() need be done; this section of code
 * isn't normally needed when saving images.
 */
static int checkexist(const char *name)
{
    FILE    *fp;
    if ((fp = fopen(name, "rb")) != NULL) {
	fclose(fp);
	printf("Image not saved, file %s already exists\n", name);
	user("");
	return(1);
    }
    return(0);
}

/*
 * Save image in industry standard .tif format.
 */
static void do_savetif(int u)
{
    int     err = 0;
    char    name[PATH_MAX];

    //
    // Create index'ed file name.
    //
    snprintf(name, sizeof(name)-1, IMAGEFILE_DIR "/" "image%d.tif", u);

    //
    // Don't overwrite existing file.
    //
    if (checkexist(name))
	return;

    //
    // Do save of entire image to disk in TIFF format.
    //
    printf("Unit %d: Saving image buffer 1 to file %s\n", u, name);
    err = pxe_saveTiff(pxdstates[u], 1, name, 1, 0, 0, -1, -1, 0, 0);
    if (err < 0) {
	printf("Unit %d: pxe_saveTiff: %s\n", u, pxd_mesgErrorCode(err));
	user("");
	return;
    }
    printf("Unit %d: Image buffer saved\n", u);
    user("");
}

/*
 * Save image in the Windows .bmp format.
 * This feature is available under Linux as well.
 */
static void do_savebmp(int u)
{
    int     err = 0;
    char    name[PATH_MAX];

    //
    // Create index'ed file name.
    //
    snprintf(name, sizeof(name)-1, IMAGEFILE_DIR "/" "image%d.bmp", u);

    //
    // Don't overwrite existing file.
    //
    if (checkexist(name))
	return;

    //
    // Do save of entire image to disk in Bitmap format.
    // Monochrome image buffers are saved as an 8 bit monochrome image,
    // color image buffers are saved as an 24 bit RGB color image.
    //
    printf("Unit %d: Saving image buffer 1 to file %s\n", u, name);
    err = pxe_saveBmp(pxdstates[u], 1, name, 1, 0, 0, -1, -1, 0, 0);
    if (err < 0) {
	printf("Unit %d: pxe_saveBmp: %s\n", u, pxd_mesgErrorCode(err));
	user("");
	return;
    }
    printf("Unit %d: Image buffer saved\n", u);
    user("");
}

/*
 * Save image in the JPEG format.
 * This requires the PXIPL library.
 */
static void do_savejpeg(int u)
{
    #if USE_PXIPL
	int	err = 0;
	char	name[PATH_MAX];

	//
	// Create index'ed file name.
	//
	snprintf(name, sizeof(name)-1, IMAGEFILE_DIR "/" "image%d.jpg", u);

	//
	// Don't overwrite existing file.
	//
	if (checkexist(name))
	    return;

	//
	// Do save of entire image to disk in JPEG format.
	//
	printf("Unit %d: Saving image buffer 1 to file %s\n", u, name);
	err = pxio8_jpegwrite(NULL, pxe_defineImage(pxdstates[u], 1,1,0,0,-1,-1,"RGB"), NULL, name, 8, NULL);
	if (err < 0) {
	    printf("Unit %d: pxio8_jpegwrite: %s\n", u, pxd_mesgErrorCode(err));
	    user("");
	    return;
	}
	printf("Unit %d: Image buffer saved\n", u);
	user("");
    #endif
}

/*
 * Display image as text characters.
 *
 * Not expected to produce a nice looking image,
 * as it is limited to a text mode display;
 * But avoids interfacing to the Linux screen manager.
 * Nor does it bother to try to do so efficiently; normally
 * the pxd_readuchar() would be called once for the entire
 * image, or perhaps once per line.
 */
static void do_display(int u)
{
    uchar   charcodes[] = { ' ', '.', ':', '-',
			    '+', '*', 'e', 'm',
			    'I', 'H', 'B', 'M',
			  /* 0xB0, 0xB1, 0xB2, 0xDB */ };
    int     dx, dy, err = 0;
    #define DISPX   72
    #define DISPY   20

    for (dy = 0; dy < DISPY; dy++) {
	for (dx = 0; dx < DISPX; dx++) {
	    uchar   value[1];
	    int     ix = (dx*pxe_imageXdim(pxdstates[u]))/DISPX;
	    int     iy = (dy*pxe_imageYdim(pxdstates[u]))/DISPY;
	    err = pxe_readuchar(pxdstates[u], 0x1, 1, ix, iy, ix+1, iy+1, value, 1, "Grey");
	    value[0] = (value[0]*(sizeof(charcodes)-1))/255;
	    printf("%c", charcodes[value[0]]);
	}
	printf("\n");
    }
    if (err < 0)
	printf("Unit %d: pxe_readuchar: %s\n", u, pxd_mesgErrorCode(err));
    printf("Unit %d: Image buffer 'displayed'\n", u);
    user("");
}


/*
 * Capture sequence
 */
static void do_videosequence(int u)
{
    int     err;
    //
    // Capture sequence of images into all frame buffers
    // This function returns immediately; we must wait till done.
    //
    // Unfortunately, a very slow camera might cause us to wait
    // a long time; and a very, very slow camera, or a camera
    // waiting for en external trigger, might cause us to wait forever.
    // Thus, a timeout.
    err = pxe_goLiveSeq(pxdstates[u], 1, 1, pxe_imageZdim(pxdstates[u]), 1, pxe_imageZdim(pxdstates[u]), pxe_imageIdim(pxdstates[u]));
    printf("Unit %d: pxe_goLiveSeq: %s\n", u, err>=0? "Ok": pxd_mesgErrorCode(err));
    if (err >= 0) {
	struct timeval timeval, timeval2;
	gettimeofday(&timeval, NULL);
	//
	printf("Capturing images ...");
	while (pxe_goneLive(pxdstates[u], 1, 0)) {
	    printf("\r                    \r");
	    usleep(5000);
	    printf("Capturing images ...");
	    gettimeofday(&timeval2, NULL);
	    if (timeval2.tv_sec > timeval.tv_sec+30) {
		pxe_goAbortLive(pxdstates[u], 1);
		printf("Unit %d: Image seqeunce capture aborted after 30 seconds", u);
		user("");
		return;
	    }
	    usleep(5000);
	}

	printf("\n");
    }
    //
    // Check for faults, such as erratic sync
    // or insufficient PCI bus bandwidth
    //
    pxe_mesgFault(pxdstates[u], 1);
    printf("Unit %d: Image seqeunce captured\n", u);
    user("");
}

/*
 * Save sequence
 */
static void do_savesequence(int u)
{
    int     i, err = 0;
    char    name[PATH_MAX];

    printf("Saving images ...");
    for (i = 1; i <= pxe_imageZdim(pxdstates[u]); i++) {
	snprintf(name, sizeof(name)-1, "%s/image%d_%.6d.tif", IMAGEFILE_DIR, u, i);
	name[sizeof(name)-1] = 0;

	//
	// Don't overwrite existing file.
	//
	if (checkexist(name))
	    continue;

	//
	// Do save of entire image to disk in TIFF format.
	//
	err = pxe_saveTiff(pxdstates[u], 1, name, i, 0, 0, -1, -1, 0, 0);
	if (err < 0) {
	    printf("Unit %d: pxe_saveTiff: %s\n", u, pxd_mesgErrorCode(err));
	    user("");
	    return;
	}
	printf(".");
    }
    printf("\n");
    printf("Unit %d: Image buffers saved\n", u);
    user("");

}

/*
 * Close the PIXCI(R) frame grabber
 */
static void do_close(void)
{
    int u;
    for (u = 0; u < UNITS; u++) {
	pxe_PIXCIclose(pxdstates[u]);
	#if PXELIB_ENHANCED
	    pxe_XCLIBuninstantiate(pxdstates[u]);
	    pxdstates[u] = NULL;
	#endif
    }
    user("PIXCI(R) frame grabber(s) closed");
}

/*
 * Here and elsewhere: we declare as 'static'
 * to avoid compiler's 'missing prototype' warnings.
 */
static void hello(void)
{
    printf("\n\n");
    printf("PIXCI(R) Frame Grabbers -  XCLIB 'C' Library\n");
    printf("XCLIBEL5.C - Example program\n");
    printf("Copyright (C)  2004-2018  EPIX, Inc.  All rights reserved.\n");
    printf("\n");
    printf("This program is best used by executing this program\n");
    printf("one step at a time, while simultaneously reading\n");
    printf("the XCLIB documentation and program listing.\n");
    user("");
}

/*
 *  MAIN:
 *
 *  Each library function is demonstrated in its own subroutine,
 *  the main calls each subroutine to produce the interactive demonstration.
 *
 *  It is suggested that this program source be read at the same time
 *  as the compiled program is executed.
 *
 */
int main(void)
{
    int u;

    //
    // Say Hello
    //
    hello();


    //
    // Open and set video format.
    //
    if (do_open() < 0)
	return(1);

    //
    // Basic video operations
    // Report info, snap image, snap
    // another image.
    for (u = 0; u < UNITS; u++) {
	do_imsize(u);
	do_vidsize(u);
	do_video1(u);
	do_video1(u);
    }

    //
    // Show pixel values
    //
    for (u = 0; u < UNITS; u++) {
	if (pxe_imageCdim(pxdstates[u]) == 1) {
	    bw_display1(u);
	    bw_display2(u);
	} else {
	    color_display1(u);
	    color_display2(u);
	    color_display3(u);
	    color_display4(u);
	    color_display5(u);
	    color_display6(u);
	}
    }

    //
    // Save image
    //
    for (u = 0; u < UNITS; u++) {
	do_savetif(u);
	do_savebmp(u);
	#if USE_PXIPL
	    do_savejpeg(u);
	#endif
    }

    //
    // Display image.
    //
    for (u = 0; u < UNITS; u++) {
	do_display(u);
    }

    //
    // Do General Purpose Input/Output signals
    //
    for (u = 0; u < UNITS; u++) {
	do_extin1(u);
	do_extin2(u);
	do_extout1(u);
	do_extout2(u);
    }

    //
    // Do sequence capture & save
    //
    for (u = 0; u < UNITS; u++) {
	do_videosequence(u);
	do_savesequence(u);
    }


    //
    // All done
    //
    do_close();
    return(0);
}
